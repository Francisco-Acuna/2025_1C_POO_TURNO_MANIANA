package ar.org.centro8.curso.java.repositories;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.centro8.curso.java.entities.Alumno;
import ar.org.centro8.curso.java.repositories.interfaces.I_AlumnoRepository;

/*
 * En el mundo del desarrollo de software, cuando hablamos de clases que se encarguen de
 * interacturar con la base de datos para guardar, buscar, o actualizar los objetos, se vana referir 
 * como DAO (Data Acces Object) y Repository(Repositorio).
 * Ambos cumplen con el mismo propósito: abstraer la lógica de la persistencia para que el 
 * resto de nuestra aplicación no tenga que preocuparse por los detalles de SQL o de cómo
 * funciona la base de datos.
 * DAO es el término más tradicional para una clase que implementa directamente estas operaciones
 * de acceso a datos de bajo nivel SQL
 * Repository es un concepto más moderno y de más alto nivel, muy poplar en frameworks como 
 * Spring Boot con Spring Data JPA
 * Un repositorio sería como una "colección de objetos en memoria", aunque por detrás estén
 * guardados en la base de datos.
 */
@Repository
public class AlumnoDAO implements I_AlumnoRepository{
    //creamos un objeto de DataSource que nos permite obtener la conexión a la BD
    private final DataSource DATASOURCE;
    
    //definimos una serie de atributos estáticos (para ahorrar memoria) y constantes (para 
    //garantizar que no se cambie la consulta en tiempo de ejecución)
    //Representan consultas SQL.
    //Agrupadas al inicio nos permiten una mayor claridad de código y facilita el mantenimiento
    private static final String SQL_CREATE =
        "INSERT INTO alumnos(nombre, apellido, edad, idCurso, activo) VALUES (?,?,?,?,?)";
    //los signos de pregunta son marcadores de posición para los valores que se establecerán
    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM alumnos WHERE id=?";
    private static final String SQL_FIND_ALL =
        "SELECT * FROM alumnos";
    private static final String SQL_UPDATE =
        "UPDATE alumnos SET nombre=?, apellido=?, edad=?, idCurso=?, activo=? WHERE id=?";
    private static final String SQL_DELETE =
        "DELETE FROM alumnos WHERE id=?";
    private static final String FIND_BY_CURSO =
        "SELECT * FROM alumnos WHERE idCurso=?";

    public AlumnoDAO(DataSource dataSource){
        this.DATASOURCE = dataSource;
    }
    // de esta manera, el repositorio queda configurado con la fuente de conexiones
    //que usará siempre, el repositorio no crea su propio datasource, sino que se le proporciona
    //uno configurado con HikariCP
    //Mantiene un diseño limpio y testeable, ya que se pueden crear varias instancias con distintos
    //DataSource, esto puedo representar distintas bases como la de producción, desarrollo, test, etc
    //sin necesidad de tocar código interno.

    @Override
    public void create(Alumno alumno) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) { //obtenemos la conexión
            //PreparedStatement es una interfaz de Java que representa una plantilla de consulta
            //o comando SQL. Sirve para ejecutar consultas SQL de forma segura y eficiente, especialmente
            //cuando estas consultas usan valores variables. 
            //Llamamos al método preparedStatement de la conexión, primero le pasamos la constante de la
            //sentencia SQL que queremos ejecutar y luego, Statement.RETURN_GENERATED_KEYS le indica a la 
            //base de datos que después de ejecutar el INSERT debe devolver las claves generadas automáticamente
            //(por lo general es el ID autoincrementable de la nueva fila)
            ps.setString(1, alumno.getNombre()); //el 1 se refiere a la primera posición del ?  
            ps.setString(2, alumno.getApellido());
            ps.setInt(3, alumno.getEdad());
            ps.setInt(4, alumno.getIdCurso());
            ps.setBoolean(5, alumno.isActivo());
            ps.executeUpdate(); //ejecuta la sentencia SQL_INSERT. Para sentencias que modifican
            //datos (INSERT, UPDATE y DELETE), se utiliza executeUpdate()
            try (ResultSet keys = ps.getGeneratedKeys()) { //recupera las claves autogeneradas
                //sería el id de la nueva fila insertada.
                //ResultSet es una interfaz en JDBC que representa un conjunto de resultados de una
                //consulta sql. Como convención, se utiliza la palabra keys como nombre de la variable
                // porque contiene las llaves generadas.
                //getGeneratedKeys() es un método que se utiliza para recuperar el ResultSet que contiene
                //culaquier clave generada automáticamente por la base de datos.
                if(keys.next()){
                    //mueve el cursor del ResultSet a la siguiente fila. Si hay al menos una fila, es decir,
                    // si se generó un id.
                    //Es esencial llamar a next() antes de intentar leer cualquier dato de un ResultSet
                    alumno.setId(keys.getInt(1)); //le inserta el id que devolvió el RETURN_GENERATED_KEYS
                    //getInt() recupera el valor entero de la primera columna del ResultSet de las claves
                    //generadas. Asumimos que la primera columna contiene el ID autoincremental de la fila
                    //recién insertada.
                    //alumno.setId() establece el ID generado en el objeto alumno que se pasó al método
                    //es importante porque después de esta operación, el objeto alumno en memoria tendrá
                    //el ID real que se le asignó en la base de datos.
                }                
            }  
        }
    }

    @Override
    public Alumno findById(int id) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) { //ejecuta la consulta SQL (SELECT)
                //para consultas que devuelven datos, se utiliza executeQuery() que retorna
                //un ResultSet con los resultados de la consulta
                if(rs.next()){
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Alumno> findAll() throws SQLException {
        List<Alumno> lista = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()){
            while(rs.next()){
                lista.add(mapRow(rs));
            }
        } 
        return lista;
    }

    @Override
    public int update(Alumno alumno) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, alumno.getNombre());
            ps.setString(2, alumno.getApellido());
            ps.setInt(3, alumno.getEdad());
            ps.setInt(4, alumno.getIdCurso());
            ps.setBoolean(5, alumno.isActivo());
            ps.setInt(6, alumno.getId());
            int filasAfectadas = ps.executeUpdate(); //almacena el resultado de la ejecución
            return filasAfectadas; //devuelve el número de filas afectadas
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        } 
    }

    @Override
    public List<Alumno> findByCurso(int idCurso) throws SQLException {
        List<Alumno> lista = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(FIND_BY_CURSO)) {
            ps.setInt(1, idCurso);
            try (ResultSet rs = ps.executeQuery()) {
                while(rs.next()){
                    lista.add(mapRow(rs));
                }
            } 
        } 
        return lista;
    }


    //creamos un método que centraliza la lógica de mapeo de ResultSet a objeto Java,
    //evitando la duplicación de código y haciendo el código más limpio.
    private Alumno mapRow(ResultSet rs) throws SQLException{
        //es privado porque solo lo vamos a utilizar dentro de esta clase
        //toma una fila de resultados de la BD y la convierte en un objeto del tipo Alumno
        Alumno a = new Alumno();
        a.setId(rs.getInt("id"));
        a.setNombre(rs.getString("nombre"));
        a.setApellido(rs.getString("apellido"));
        a.setEdad(rs.getInt("edad"));
        a.setIdCurso(rs.getInt("idCurso"));
        a.setActivo(rs.getBoolean("activo"));
        return a;
    }



}

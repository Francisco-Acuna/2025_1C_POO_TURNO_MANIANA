CREATE DATABASE IF NOT EXISTS colegio_matutino;
USE colegio_matutino;

DROP TABLE IF EXISTS alumnos;
DROP TABLE IF EXISTS cursos;

CREATE TABLE cursos(
    id int auto_increment primary key,
    titulo varchar(100) not null check(length(titulo)>=3),
    profesor varchar(100) not null check(length(profesor)>=3),
    dia enum('LUNES', 'MARTES', 'MIERCOLES', 'JUEVES', 'VIERNES') not null,
    turno enum('MAÑANA', 'TARDE', 'NOCHE') not null,
    activo boolean default true
);


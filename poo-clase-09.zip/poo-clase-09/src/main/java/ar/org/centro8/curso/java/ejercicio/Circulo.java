package ar.org.centro8.curso.java.ejercicio;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
public class Circulo extends FiguraGeometrica{

    //atributos
    private double radio;

    //métodos
    @Override
    public double getPerimetro(){
        return radio * Math.PI * 2;
    }

    @Override
    public double getSuperficie(){
        return Math.PI * Math.pow(radio, 2);
    }
    
}

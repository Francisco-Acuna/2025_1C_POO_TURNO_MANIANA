package ar.org.centro8.curso.java.tests;

import ar.org.centro8.curso.java.entidades.herencia.Cliente;
import ar.org.centro8.curso.java.entidades.herencia.Direccion;
import ar.org.centro8.curso.java.entidades.herencia.Empleado;
import ar.org.centro8.curso.java.entidades.herencia.Persona;
import ar.org.centro8.curso.java.entidades.relaciones.Cuenta;

public class TestHerencia {
    public static void main(String[] args) {
        /*
         * Herencia
         * Es un mecanismo para reutilizar miembros de una clase.
         * Esto favorece la extensión y especialización de comportamientos.
         * Es la relación más fuerte entre clases.
         * La renocemos con las palabras "es un/a".
         * En este caso, las clases pueden derivar de otras clases.
         * La clase derivada es la subclase y la clase de la que deriva es la superclase.
         * También se las conoce como clases hijas y clase padre.
         * Una clase en Java solo puede tener una única superclase directa.
         * Java no soporta la herencia múltiple.
         */

        System.out.println("** Test de clase Direccion **");

        Direccion direccion1 = new Direccion("Jujuy", 1999, "2", "C");
        System.out.println(direccion1);

        Direccion direccion2 = new Direccion("Belgrano", 10, "PB", "H", "Moreno");
        System.out.println(direccion2);

        System.out.println("** Clase Direccion funcionando correctamente **");

        System.out.println();

        /* System.out.println("** Test Clase Persona **");

        Persona persona1 = new Persona("Burzun", "García", 30, direccion1);
        System.out.println(persona1);
        persona1.saludar();

        System.out.println("**Clase Persona funcionando correctamente**"); */

        System.out.println("**Test clase Empleado**");
        Empleado empleado1 = new Empleado("Martin", "Nogales", 20, direccion2, 100, 500000);
        System.out.println(empleado1);
        System.out.println(empleado1.getNombre());
        empleado1.saludar();

        System.out.println("**Clase Empleado funcionando correctamente**");

        System.out.println();

        System.out.println("**Test Clase Cliente**");

        Cuenta cuenta1 = new Cuenta(12, "Patacones reales");

        Cliente cliente1 = new Cliente("Roberto", "DeNiro", 65, direccion1, 100, cuenta1);
        System.out.println(cliente1);
        cliente1.saludar();
        cliente1.getCuenta().depositar(100000);
        System.out.println(cliente1.getCuenta());

        System.out.println("**Clase Cliente funcionando correctamente**");

        // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        /*
         * Polimorfismo
         * Es la capacidad de un objeto o método para tomar muchas formas, lo que permite
         *  que el mismo método pueda comportarse de maneras distintas dependiendo del contexto.
         * 
         * Hay dos clases de polimorfismo:
         * 
         * 1. Polimorfismo sin redefinición, es en tiempo de compilación (sobrecarga):
         *  Se produce cuando en una misma clase existen varios métodos con el mismo nombre,
         *  pero con diferentes parámetros (diferentes firmas). Esto permite ejecutar acciones
         *  similares sobre distintos tipos o números de argumentos.
         * 
         * 2. Polimorfismo con redefinición, en en tiempo de ejecución (sobreescritura):
         *  Se produce cuando una subclase redefine un método heredado de la superclase
         *  (usando @Override). Esto permite que una variable de tipo de la superclase, 
         *  pueda referenciar objetos de diferentes subclases, comportándose de manera
         *  distinta, según la instancia concreta.
         */

         Persona persona1 = new Empleado("Matias", "Gonzalez", 20, direccion2, 56, 600000);
         Persona persona2 = new Cliente("Tomás", "Valdez", 30, direccion2, 15, 
                                        new Cuenta(12, "pesos argentinos"));

        //polimorfismo
        persona1.saludar();
        persona2.saludar();
    }
}

package ar.org.centro8.curso.java.entidades.relaciones;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
public class EmpleadoAsociacionSimple {
    //la asociación simple es un tipo de relación y es la menos acoplada
    //se reconce con las palabras "usa un/a"
    //en este caso, un empleado usa un auto

    private int legajo;
    private String nombre;
    private String apellido;

    public void usarAuto(Auto auto){
        System.out.println("El empleado está usando el auto " + auto);
    }

}

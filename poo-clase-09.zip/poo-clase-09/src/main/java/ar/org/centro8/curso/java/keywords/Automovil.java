package ar.org.centro8.curso.java.keywords;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@Getter
@RequiredArgsConstructor
@ToString
public class Automovil {
    private final String marca;
    private final String modelo;
    private final String color;
    private static int velocidad;

    /*
     * final
     * Cuando una variable o atributo es declarado final, queda constante. No se puede
     * modificar su valor. La keyword (palabra reservada) final a nivel atributo o 
     * variable, determina que la misma será constante.
     * En métodos, final evita que estos métodos sean sobreescritos en clases hijas.
     * A nivel clase, final indica que una clase no puede tener clases hijas.
     */

    /*
     * static
     * Un atributo estático pertenece a la clase, no a los objetos.
     * Su estado es compartido por todas las instancias de la clase.
     * Se accede a un atributo estático directamente a través del nombre de la clase.
     */

    //cuando un método es estático, significa que ese método pertenece a la clase
    //si el atributo que se modifica es estático, el método debe ser estático.
    //No podemos utilizar el this. porque hace referencia al objeto, y el atributo
    //estático no pertenece al objeto en si mismo. 
    public static void acelerar(int kilometros){
        velocidad += kilometros;
    }

    //Desde un método estático, solo puedo hacer referencia a atributos estáticos de la 
    //clase. 
    //Desde un método no estático puedo llamar a miembros estáticos y no estáticos.

    public static int getVelocidad(){
        return velocidad;
    }
}

package ar.org.centro8.curso.java;

public class Auto {
    //una clase es una plantilla o molde que definen los atributos
    //y métodos que tendrán los objetos

    //atributos de la clase
    //son variables que indican las características de la clase
    String marca;
    String modelo;
    String color;
    int velocidad;

    //constructores
    //si no los definimos, se crea uno vacío por defecto
    //los constructores son métodos que tienen el mismo nombre que la clase
    Auto(){} //constructor vacío

    //sobrecarga de constructores
    //constructor completo
    public Auto(String marca, String modelo, String color, int velocidad) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.velocidad = velocidad;
    }

    //más sobrecarga de constructores
    public Auto(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.velocidad = 0;
    }

    //más sobrecarga
    

    //métodos -> bloques de código que definen el comportamiento
    void acelerar(){
        velocidad += 10;
    }

    /**
     * Constructor para autos de la marca Ford
     * @param modelo
     * @param color
     */
    public Auto(String modelo, String color) {
        this.marca = "Ford";
        this.modelo = modelo;
        this.color = color;
        this.velocidad = 0;
    }

    void frenar(){
        velocidad -= 10;
    }

    //sobrecarga de métodos
    void acelerar(int kilometros){
        velocidad += kilometros;
    }

    /**
     * Si el turbo es true, se incrementa el doble de kilómetros a la velocidad
     * @param kilometros = son los kilómetros que se van a incrementar
     * @param turbo = true si tiene turbo, false si no tiene
     */
    void acelerar(int kilometros, boolean turbo){
        if(turbo) velocidad += kilometros * 2;
        else velocidad += kilometros;
    }

    void frenar(int kilometros){
        // velocidad -= kilometros;
        if(velocidad-kilometros<0) velocidad=0;
        else velocidad -= kilometros;
    }

    void imprimirVelocidad(){
        System.out.println(velocidad);
    }

    int obtenerVelocidad(){
        return velocidad;
    }

    @Override
    public String toString() {
        return "El auto es un " + marca + ", modelo " + modelo + 
                            ", color " + color + " y tiene una velocidad de " 
                            + velocidad + "km/h.";
    }

    

}

package ar.org.centro8.curso.java.tests;

import ar.org.centro8.curso.java.entidades.encapsulamiento.Empleado;

public class TestEncapsulamiento {
    public static void main(String[] args) {
        
        //creamos un objeto de la clase
        // Empleado empleado1 = new Empleado();
        //no se puede crear un objeto con constructor vacío
        //porque no existe, no está declarado en la clase

        Empleado empleado1 = new Empleado(1, "Mariana", "Gonzalez");
        System.out.println(empleado1);

        // empleado1.nombre = "Maria";
        //no se puede acceder a un miembro privado, directamente
        empleado1.setNombre("Maria");
        System.out.println(empleado1.getNombre());
    }
}

package ar.org.centro8.curso.java.tests;

import java.io.FileInputStream;
import java.io.File;

import ar.org.centro8.curso.java.entidades.excepciones.GeneradorDeExcepciones;
import ar.org.centro8.curso.java.entidades.excepciones.NoHayMasPasajesException;
import ar.org.centro8.curso.java.entidades.excepciones.Vuelo;

public class TestExceptions {
    public static void main(String[] args) {
        // System.out.println(10/0);
        // System.out.println("Esta línea no se ejecuta");

        //manejo de excepciones
        //estructura try-catch-finally (mecanismo para el manejo de excepciones)
        try { //obligatorio
            /*
             * En este bloque se colocan todas las sentencias que pueden lanzar una Exception.
             * Si no se produce ningún error, el bloque se ejecuta normalmente y salta al
             * bloque del finally (si es que existe).
             * Si se lanza una Exception, la ejecución del bloque try se detiene automáticamente
             * y se transfiere el control al bloque del catch
             */
        } catch (Exception e) { // obligatorio
            /*
             * En este bloque se definen las acciones a realizar cuando se produce una Exception-
             * Se captura la excepción mediante un objeto del tipo Exception que contiene 
             * información sobre el error.
             * El programa continua su ejecución después de este bloque, sin detenerse abruptamente.
             * Salta al bloque finally (si es que existe)
             */
        } finally { // opcional
            /*
             * Este bloque se ejecuta siempre, independientemente de que se haya lanzado o no una Exception
             * Se utiliza para liberar recursos o realizar tareas de limpieza, como cerrar archivos, 
             * conexiones a bases de datos, etc.
             * Las variables declaradas dentro de los bloques de try o de catch no son accesibles desde 
             * este bloque, ya que el alcance (scope) es local a esos bloques anteriores.
             */
        }

        //estas sentencias se ejecutan siempre
        //el programa finaliza normalmente

        //Ejemplo
        try {
            System.out.println(10/0);
            System.out.println("Esta sentencia no se ejecuta si se lanza una excepción");
        } catch (Exception e) {
            System.out.println("Mensaje del bloque catch: OCURRIÓ UN ERROR");
            System.out.println(e); //imprime el objeto del error
            System.out.println(e.getMessage()); //mensaje corto con la descripción
            System.out.println(e.getLocalizedMessage()); //similar a getMessage pero devuelve
            //un mensaje traducido según la configuración regional (si es que fue sobreescrita)
            System.out.println(e.getCause()); //retorna la causa (otra excepción) que provocó
            //la excepción actual, lo que permite encadenar excepciones y entender la raíz del problema
            e.printStackTrace(); //imprime la traza completa de la pila. Lo que facilita la depuración
            //al mostrar la secuencia de llamadas que condujeron a la excepción.
        } finally {
            System.out.println("Bloque finally: Este bloque se ejecuta siempre.");
        }

        System.out.println("Mensaje fuera del bloqe try-catch-finally. Se ejecuta sin problemas.");

        //uso del bloque finally
        // String mensaje = "Hola Mundo!";
        // try {
        //     mensaje = "<ini>" + mensaje;
        //     return;
        // } catch (Exception e) {
        //     e.printStackTrace();
        // } finally {
        //     mensaje += "<fin>";
        //     System.out.println(mensaje);
        // }

        //esto podría lanzar una excepción (ArithmeticException), que es una unchecked, por 
        //lo tanto, no tenemos la obligación de controlarla. Pero si lanza la excepción, detiene el programa
        //GeneradorDeExcepciones.generar(true);

        //las excepciones del checked, estamos obligados a capturarlas
        // FileInputStream in = new FileInputStream(new File("texto.txt"));
        try {
            FileInputStream in = new FileInputStream(new File("texto.txt"));
        } catch (Exception e) {
            e.printStackTrace();
        }

        //cualquiera de las excepciones Unchecked /anchekt/ pueden detener el programa
        try {
            // GeneradorDeExcepciones.generar(); //ArrayIndexOutOfBoundsException
            // GeneradorDeExcepciones.generar(true); //ArithmeticException
            // GeneradorDeExcepciones.generar("33x"); //NumberFormatException
            // GeneradorDeExcepciones.generar("Hola", 20); //StringIndexOutOfBoundsException
        } catch (Exception e) {
            System.out.println(e);
        }

        //captura personalizada de excepciones
        //tendremos varios catch porque queremos personalizar la salida, de acuerdo al tipo
        //de error, la excepción va ir viendo en qué catch entra, como si fuera un switch case.
        try {
            // GeneradorDeExcepciones.generar(); // esto genera un ArrayIndexOutOfBounesException
            GeneradorDeExcepciones.generar("Hola", 10); //lanza StringIndexOutOfBounesException
        } catch (ArithmeticException e) { System.out.println("Error de división por cero");
        } catch (NumberFormatException e) { System.out.println("Error de formato de número incorrecto");
        } catch (NullPointerException e) { System.out.println("Error de puntero nulo");
        // } catch (ArrayIndexOutOfBoundsException e) { System.out.println("Índice fuera de rango");
        // } catch (StringIndexOutOfBoundsException e) { System.out.println("Índice fuera de rango");
        } catch (ArrayIndexOutOfBoundsException | StringIndexOutOfBoundsException e) { System.out.println("Índice fuera de rango");               
        // sintaxis multicatch introducida en JDK7 para capturar varios tipos de excepciones en un solo bloque
        } catch (IndexOutOfBoundsException e) {System.out.println("Índice fuera de rango");
        //la otra opción es llamar a la clase padre
        } catch (Exception e) { System.out.println("Ocurrió un error inesperado");
        }

        //ahora vamos a utilizar las excepciones para validar reglas de negocio

        Vuelo vuelo1 = new Vuelo("AERO121", 100);
        // vuelo1.venderPasajes(10); estamos obligados a controlar la excepción

        try {
            vuelo1.venderPasajes(10);
            vuelo1.venderPasajes(90);
            vuelo1.venderPasajes(1);
        } catch (NoHayMasPasajesException e) {
            System.out.println(e);
        }

        System.out.println("Vuelo1: " + vuelo1);






    }
}

package ar.org.centro8.curso.java.entidades.encapsulamiento;

public class Empleado {

    /*
     * Modificadores de acceso o visibilidad aplicables a atributos y métodos:
     * private: Es el nivel de acceso más restringido.
     *          Es accesible solo para la clase que lo está definiendo.
     *          Se utiliza para declarar miembros que solo deben ser utilizados
     *          por la misma clase.
     * public:  Es el modificador de acceso más sencillo.
     *          Todas las clases de todos los paquetes tienen acceso a los
     *          miembros públicos.
     * protected:   Solo se puede acceder desde el mismo paquete o desde 
     *              clases que extiendan de la clase que lo implementa (incluso
     *              si están en otro paquete).
     * default: Es cuando no ponemos un modificador específico.
     *          Solo se puede acceder desde las clases del mismo paquete.
     */

    //atributos
    private int id;
    private String nombre;
    private String apellido;
    private double sueldoBasico;

    /*
     * Modificadores de acceso o visibilidad aplicado a constructores:
     * private: Ninguna clase puede crear un objeto de esta clase.
     *          La clase puede contener métodos públicos y estáticos que
     *          pueden construir un objeto y devolverlo.
     * public:  Cualquiera puede crear un objeto de la clase.
     * protected:   Solo las subclases y las clases que estén dentro del
     *              mismo paquete pueden crear los objetos.
     * default: Nadie fuera del paquete puede crear objetos de la clase.
     */

    public Empleado(int id, String nombre, String apellido, double sueldoBasico) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.sueldoBasico = sueldoBasico;
    }

    public Empleado(int id, String nombre, String apellido) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.sueldoBasico = 750000;
    }    


    //métodos
    /*
     * getters y setters
     * Son métodos que permiten acceder y modificar los atributos privados de
     * una clase de forma controlada, promoviendo el principio de encapsulamiento
     * junto con el de ocultación.
     * En Java, se recomienda declarar los atributos como privados para proteger
     * el estado interno de la clase. Los getters y setters actúan como una 
     * interfaz para leer y modificar esos atributos, sin exponerlos directamente.
     * Con estos métodos se puede agregar una lógica adicional, como validaciones
     * o transformaciones, antes de asignar un valor o de devolverlo. Por ejemplo,
     * se podría validar que no se ingrese una edad negativa.
     */

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getApellido() {
        return apellido;
    }
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    public double getSueldoBasico() {
        return sueldoBasico;
    }
    public void setSueldoBasico(double sueldoBasico) {
        this.sueldoBasico = sueldoBasico;
    }

    @Override
    public String toString() {
        return "Empleado [id=" + id + ", nombre=" + nombre + ", apellido=" + apellido + ", sueldoBasico=" + sueldoBasico
                + "]";
    }

    
    

}

package ar.org.centro8.curso.java.tests;

import ar.org.centro8.curso.java.entidades.encapsulamiento.Empleado;
import ar.org.centro8.curso.java.entidades.encapsulamiento.EmpleadoL;

public class TestEncapsulamiento {
    public static void main(String[] args) {
        
        //creamos un objeto de la clase Empleado
        //Empleado empleado1 = new Empleado();
        //no se puede crear un objeto con constructor vacío
        //porque no existe, no está declarado en la clase

        Empleado empleado1 = new Empleado(1, "Mariana", "Gonzalez");
        System.out.println(empleado1);

        // empleado1.nombre = "Maria";
        //no se puede acceder a un miembro privado, directamente
        empleado1.setNombre("Maria"); //con set modifico el valor
        System.out.println(empleado1.getNombre()); //con get obtengo el valor

        //probamos la clase que utiliza Lombok
        EmpleadoL empleado2 = new EmpleadoL(2, "Miguel", "Perez", 900000);
        System.out.println(empleado2);

        System.out.println(empleado2.getNombre());
        // System.out.println(empleado2.nombre); no puedo acceder a un miembro privado

        System.out.println(empleado2.getApellido());

        System.out.println(empleado2.getSueldoBasico());

        empleado2.setSueldoBasico(900010);

    }
}

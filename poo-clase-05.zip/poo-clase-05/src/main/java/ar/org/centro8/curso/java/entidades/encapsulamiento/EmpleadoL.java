package ar.org.centro8.curso.java.entidades.encapsulamiento;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/*
 * Lombok es una librería para Java que reduce código repetitivo al generar
 * automáticamente en tiempo de compilación, algunas partes comunes de las clases.
 * 
 */
@Getter //agrega todos los getters automáticamente
@Setter //agrega todos los setters
@AllArgsConstructor //genera el constructor completo (con todos los parámetros)
//@NoArgsConstructor -> genera el constructor vacío
//@RequiredArgsConstructor -> genera un constructor que incluye todos los atributos
//declarados como final o aquellos mascados con @NonNull
@ToString //genera el toString()
public class EmpleadoL {

    //atributos
    private int id;
    private String nombre;
    private String apellido;
    //con estas anotaciones, estamos indicando que el atributo no tendrá
    //el getter y setter generado automáticamente por Lombok
    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    private double sueldoBasico;

    public EmpleadoL(int id, String nombre, String apellido) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.sueldoBasico = 750000;
    }

    public double getSueldoBasico() {
        System.out.println("Para conocer el sueldo básico del empleado," + 
                            " comunicarse con el supervisor del área.");
        return 0.0;
    }

    public void setSueldoBasico(double sueldoBasico) {
        System.out.println("Se descuenta de la modificación un %15");
        this.sueldoBasico = sueldoBasico * 0.85;
    }

    

}

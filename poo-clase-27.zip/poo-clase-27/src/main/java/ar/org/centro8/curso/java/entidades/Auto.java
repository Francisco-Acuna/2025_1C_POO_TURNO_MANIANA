package ar.org.centro8.curso.java.entidades;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class Auto implements Comparable<Auto> {
    private String marca;
    private String modelo;
    private String color;

    @Override
    public int compareTo(Auto otroAuto) {
        String thisAuto = this.getMarca() + "," + this.getModelo() + "," + this.getColor();
        String autoOtro = otroAuto.getMarca() + "," + otroAuto.getModelo() + "," + otroAuto.getColor();
        return thisAuto.compareTo(autoOtro);
    }

    /*
     * El método copareTo() define el orden natural de una clase que implenta Comparable<T>
     * El orden natural es la forma predeterminada de comparar las instancias de la clase.
     * Valor de retorno:
     *  - Un valor menor a 0 si this es menor que el objeto que entra como parámetro
     *  - Un 0 si son iguales
     *  - Un valor mayor a 0 si this es mayor que el objeto que entra como parámetro
     */
}

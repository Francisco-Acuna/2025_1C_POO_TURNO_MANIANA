package ar.org.centro8.curso.java.tests;

import ar.org.centro8.curso.java.entidades.Auto;

public class TestArrays {
    public static void main(String[] args) {
        //Arrays 

        /*
         * Un Array es una estructura de datos en Java que permite almacenar múltiples
         * valores del mismo tipo de dato en una ubicación contínua de memoria.
         * Se utiliza cuando necesitamos manejar un conjunto fijo de elementos relacionados.
         */

        Auto[] autos;
        //solo se pueden almacenar objetos del tipo Auto
        autos = new Auto[4];
        //la longitud del vector es de 4. Esto significa que va a almacenar 4 elementos.
        //los vectores son estáticos, esto quiere decir que no se pueden achicar ni agrandar.
        //si necesito otro tamaño de vector, lo tengo que eliminar y volver a crear

        //los vectores tienen un proceso de inicialización automático
        //los tipos de datos referenciados, se inicializan en null
        for (int i = 0; i < autos.length; i++) {
            System.out.println(autos[i]);
        }

        //los tipos de datos numéricos se inicializan en 0
        int num[] = new int[4];
        for (int i = 0; i < num.length; i++) {
            System.out.println(num[i]);
        }

        //inicialización manual del vector
        autos[0] = new Auto("Fiat", "Palio", "Verde");
        autos[1] = new Auto("VW", "Gol", "Gris");
        autos[2] = new Auto("Renault", "Kangoo Stepway", "Rojo");
        autos[3] = new Auto("Renault", "Clío 1", "Gris");

        //para mostrar los elementos de un vector, utilizamos un for
        //esto genera un recorrido por índices
        for(int i=0; i<autos.length; i++) System.out.println(autos[i]);

        //a partir del JDK 5 aparece la estructura for-each
        for(Auto auto:autos) System.out.println(auto);
        //de la lista de autos, por cada elemento de la lista, vamos a tener un objeto
        //del tipo Auto.
        //El for-each funciona tanto con Arrays como con colecciones que implentan la
        //interfaz Iterable.
        //No sirve para agregar o eliminar elementos en cada iteración.
        //No tiene acceso al índice
        

    }
}

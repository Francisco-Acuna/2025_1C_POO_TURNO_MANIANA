package ar.org.centro8.curso.java.entidades.excepciones;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@AllArgsConstructor
@ToString
public class Vuelo {
    private String nombreVuelo;
    private int cantidadPasajes;

    public synchronized void venderPasajes(int cantidad) throws NoHayMasPasajesException{
        if(cantidad > cantidadPasajes) throw new NoHayMasPasajesException(nombreVuelo, cantidadPasajes, cantidad);
        cantidadPasajes -= cantidad;
    }

    /*
     * La cláusula throws se utiliza en la firma de un método para indicar que éste podría lanzar (throw) una o más excepciones que no se manejan internamente. Es decir, se declara la posibilidad de que se produzca una excepción para que el código que llame a ese método sea consciente de ello y decida cómo manejarla (ya sea capturándola mediante try-catch o propagándola a su vez).
     * En Java, las checked exceptions (como IOException) deben ser gestionadas. Si un método puede lanzar una excepción verificada y no la maneja dentro de un bloque try-catch, es obligatorio declararlo con throws para que el compilador sepa que quien invoque el método debe encargarse del manejo de la excepción.
    */

    




}

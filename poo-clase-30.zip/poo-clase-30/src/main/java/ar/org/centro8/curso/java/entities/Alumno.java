package ar.org.centro8.curso.java.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Alumno {
    /*
    id INT auto_increment primary key,
    nombre varchar(100) not null check(length(nombre) >= 3),
    apellido varchar(100) not null check(length(apellido) >= 3),
    edad INT not null check(edad>=18 and edad<=110),
    idCurso INT not null,
    activo boolean default true
     */

    private int id;
    private String nombre;
    private String apellido;
    private int edad;
    private int idCurso;
    private boolean activo;

}

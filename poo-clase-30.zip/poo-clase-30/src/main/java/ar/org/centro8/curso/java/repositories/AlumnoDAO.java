package ar.org.centro8.curso.java.repositories;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

/*
 * En el mundo del desarrollo de software, cuando hablamos de clases que se encarguen de
 * interacturar con la base de datos para guardar, buscar, o actualizar los objetos, se vana referir 
 * como DAO (Data Acces Object) y Repository(Repository).
 * Ambos cumplen con el mismo propósito: abstraer la lógica de la persistencia para que el 
 * resto de nuestra aplicación no tenga que preocuparse por los detalles de SQL o de cómo
 * funciona la base de datos.
 * DAO es el término más tradicional para una clase que implementa directamente estas operaciones
 * de acceso a datos de bajo nivel SQL
 * Repository es un concepto más moderno y de más alto nivel, muy poplar en frameworks como 
 * Spring Boot con Spring Data JPA
 * Un repositorio sería como una "colección de objetos en memoria", aunque por detrás estén
 * guardados en la base de datos.
 */
@Repository
public class AlumnoDAO {
    //creamos un objeto de DataSource que nos permite obtener la conexión a la BD
    private final DataSource dataSource;
    
    //definimos una serie de atributos estáticos (para ahorrar memoria) y constantes (para 
    //garantizar que no se cambie la consulta en tiempo de ejecución)
    //Representan consultas SQL.
    //Agrupadas al inicio nos permiten una mayor claridad de código y facilita el mantenimiento
    private static final String SQL_CREATE =
        "INSERT INTO alumnos(nombre, apellido, edad, idCurso, activo) VALUES (?,?,?,?,?)";
    




    public AlumnoDAO(DataSource dataSource){
        this.dataSource = dataSource;
    }
    // de esta manera, el repositorio queda configurado con la fuente de conexiones
    //que usará siempre, el repositorio no crea su propio datasource, sino que se le proporciona
    //uno configurado con HikariCP
    //Mantiene un diseño limpio y testeable, ya que se pueden crear varias instancias con distintos
    //DataSource, esto puedo representar distintas bases como la de producción, desarrollo, test, etc
    //sin necesidad de tocar código interno.






}

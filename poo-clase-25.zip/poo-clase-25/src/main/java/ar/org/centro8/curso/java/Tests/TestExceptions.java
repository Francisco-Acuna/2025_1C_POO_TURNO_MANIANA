package ar.org.centro8.curso.java.Tests;

public class TestExceptions {
    public static void main(String[] args) {
        // System.out.println(10/0);
        // System.out.println("Esta línea no se ejecuta");

        //manejo de excepciones
        //estructura try-catch-finally (mecanismo para el manejo de excepciones)
        try { //obligatorio
            /*
             * En este bloque se colocan todas las sentencias que pueden lanzar una Exception.
             * Si no se produce ningún error, el bloque se ejecuta normalmente y salta al
             * bloque del finally (si es que existe).
             * Si se lanza una Exception, la ejecución del bloque try se detiene automáticamente
             * y se transfiere el control al bloque del catch
             */
        } catch (Exception e) { // obligatorio
            /*
             * En este bloque se definen las acciones a realizar cuando se produce una Exception-
             * Se captura la excepción mediante un objeto del tipo Exception que contiene 
             * información sobre el error.
             * El programa continua su ejecución después de este bloque, sin detenerse abruptamente.
             * Salta al bloque finally (si es que existe)
             */
        } finally { // opcional
            /*
             * Este bloque se ejecuta siempre, independientemente de que se haya lanzado o no una Exception
             * Se utiliza para liberar recursos o realizar tareas de limpieza, como cerrar archivos, 
             * conexiones a bases de datos, etc.
             * Las variables declaradas dentro de los bloques de try o de catch no son accesibles desde 
             * este bloque, ya que el alcance (scope) es local a esos bloques anteriores.
             */
        }

        //estas sentencias se ejecutan siempre
        //el programa finaliza normalmente

        //Ejemplo
        try {
            System.out.println(10/0);
            System.out.println("Esta sentencia no se ejecuta si se lanza una excepción");
        } catch (Exception e) {
            System.out.println("Mensaje del bloque catch: OCURRIÓ UN ERROR");
            System.out.println(e); //imprime el objeto del error
            System.out.println(e.getMessage()); //mensaje corto con la descripción
            System.out.println(e.getLocalizedMessage()); //similar a getMessage pero devuelve
            //un mensaje traducido según la configuración regional (si es que fue sobreescrita)
            System.out.println(e.getCause()); //retorna la causa (otra excepción) que provocó
            //la excepción actual, lo que permite encadenar excepciones y entender la raíz del problema
            e.printStackTrace(); //imprime la traza completa de la pila. Lo que facilita la depuración
            //al mostrar la secuencia de llamadas que condujeron a la excepción.
        } finally {
            System.out.println("Bloque finally: Este bloque se ejecuta siempre.");
        }

        System.out.println("Mensaje fuera del bloqe try-catch-finally. Se ejecuta sin problemas.");

    }
}

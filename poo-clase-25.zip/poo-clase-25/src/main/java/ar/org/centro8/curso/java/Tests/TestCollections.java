package ar.org.centro8.curso.java.Tests;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Deque;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.TreeSet;

import ar.org.centro8.curso.java.entidades.Auto;

public class TestCollections {
    public static void main(String[] args) {
        //List
        /*
         * La interface List representa una lista con índices, emula a un vector.
         * List es la única que tiene métodos definidos con índice.
         * ArrayList es una lista del tipo vector que tiene por dentro un comportamiento
         * que emula a un vector, pero que no es un vector, ya que es completamente dinámico.
         * LinkedList tiene todo el comportamiento heredado de List, pero internamente, usa
         * una lista enlazada.
         * La clase Vector implementa List, no son los vectores que hemos visto hasta ahora.
         * Es una implementación de List que internamente utiliza la tecnología de vectores.
         * No es recomendado su uso, ya que es tecnología antigua y poco performante.
         * ArrayList es una lista tipo vector y LinkedList es una lista enlazada.
         * Hay una mínima diferencia entre las dos, y tiene que ver con la performance.
         * Un ArrayList es más veloz para recorrer elementos.
         * Un LinkedList es más veloz para agregar y eliminar elementos.
         */

        List lista;
        

        lista = new ArrayList();

        //.add() método para agregar elementos a un List
        lista.add(new Auto("Peugeot", "308", "azul"));
        lista.add(new Auto("Chevrolet", "Corsa", "rojo"));
        lista.add("hola");
        lista.add(80);
        lista.add(23.45);

        //recorrido de la lista con índices
        for (int i = 0; i < lista.size(); i++) {
            System.out.println(lista.get(i));
            //el método .get() devuelve el elemento que se encuentre en el 
            //índice que le pasamos como parámetro
        }
        //el método .size() devuelve la longitud de un List

        //el método .remove() elimina un elemento
        lista.remove(4); //elimina el elemento del índice 4

        //recorrido con for-each
        for(Object o:lista) System.out.println(o);

        /*
         * Interface Iterable
         * Iterable es el padre de todas las interfaces en el framework collections.
         * Dentro de Iterable se encuentra definido foreach(), es un método default.
         * Este método realiza un recorrido, la idea es que no tengamos nosotros que
         * recorrer la lista utilizando una estructura repetitiva, si no, que sea la 
         * misma lista, la que se autorrecorra. 
         */

         System.out.println("\nRecorrido con foreach()");
         lista.forEach(item -> System.out.println(item));
         /*
          * el método foreach() recibe un objeto del tipo Consumer que define qué
          operación se ejecutará sobre cada elemento de la colección.
          Consumer es un interfaz funcional cuyo propósito es consumir un valor. 
          Representa una operación que recibe un argumento del tipo T y no devuelve nada.
          T no es un tipo concreto de dato, es un símbolo que representa un tipo genérico.
          El método foreach() por lo general se implementa con una expresión Lambda.
          Las Lambdas Expressions son funciones anónimas que aparecieron a partir del 
          JDK 8. 
          Una función anónima es una porción de código que no tiene nombre y se define
          en el sitio donde se va a utilizar. Se utilizan para simplificar código.
          */
         
        System.out.println();
        //si queremos utilizar más de una sentencia, tenemos que abrir un bloque de llaves
        lista.forEach(item -> {
            System.out.println(item);
            System.out.println("*");
        });

        //Method reference (referencia de métodos)
        System.out.println("\nRecorrido con foreach() simplificado:");
        lista.forEach(System.out::println);
        //si solo vamos a escribir una única sentencia, podemos omitir el uso del iterador
        //con el operador 4 puntos :: le estamos indicando a Java que el ítem implícito
        //lo coloque como argumento del método.

        //Recorrido con ListIterator
        /*
         * ListIterator es una interfaz especializada en recorrer colecciones que implementan
         * List. A diferencia del Iterador simple (Iterator) o del método foreach de Iterable,
         * ListIterator ofrece funcionalidades adicionales:
         * - Recorrido bidireccional: Permite avanzar y retroceder sobre las listas.
         * - Tiene acceso a índices.
         * - Permite eliminar, reemplazar y agregar elementos durante la iteración.
         */

        List nombres = new ArrayList();
        nombres.add("Ricardo");
        nombres.add("Jenny");
        nombres.add("Carlos");
        nombres.add("Ana");
        nombres.add("Marcela");

        //obtenemos el ListIterator de la lista
        ListIterator<String> li = nombres.listIterator();

        //recorrido hacia adelante
        System.out.println("\nRecorrido hacia adelante del ListIterator");
        while(li.hasNext()){ //comprueba si queda al menos un elemento más por recorrer
            int indice = li.nextIndex(); //índice del elemento que se va a devolver
            String nombre = li.next(); //devuelve el siguiente elemento
            System.out.println("Índice " + indice + ": " + nombre);
        }

        //recorrido para atrás
        System.out.println("\nRecorrido hacia atrás:");
        while(li.hasPrevious()){
            int indice = li.previousIndex();
            String nombre = li.previous();
            System.out.println("Índice: " + indice + ": " + nombre);
        }

        //reemplazar elementos
        while(li.hasNext()){
            String nombre = li.next();
            if(nombre.equals("Carlos")){
                li.set("David"); //Reemplaza Carlos por David
            }
        }

        System.out.println("\nLista después de modificar 'Carlos', por 'David'" + nombres);
        
        //agregar elementos
        li = nombres.listIterator(); //reinicio la posición del cursor
        while(li.hasNext()){
            String nombre = li.next();
            if(nombre.equals("Ana")){
                li.add("Juan"); //agrega "Juan" inmediatamente después de "Ana"
            }
        }

        System.out.println("\nLista después de agregar a 'Juan' luego de 'Ana': " + nombres);

        //eliminar elementos
        li = nombres.listIterator();
        while(li.hasNext()){
            String nombre = li.next();
            if(nombre.equals("Jenny")){
                li.remove(); //elimina el elemento
            }
        }

        System.out.println("\nLista después de eliminar a 'Jenny': " + nombres);

        //Uso de Generics 
        /*
         * Para especificar el tipo de dato de una lista o colección, lo hago a través del Generic.
         * Los Generics aparecieron a partir del JDK 5 y son una característica que permiten
         * crear clases, interfaces o métodos con tipos de datos parametrizados.
         * Esto significa que podemos definir estructuras de datos y métodos que funcionen
         * con cualquier tipo de datos, pero manteniendo la seguridad de los tipos en tiempo de 
         * compilación. Los Generics permiten que una clase o método trabaje con diferentes tipos
         * de datos sin tener que escribir varias versiones del mismo código.
         */

        // List<Auto> lista2 = new ArrayList<>();
        List<Auto> lista2 = new LinkedList<>();
        //no se pueden crear colecciones de tipos de datos primitivos.
        //en su lugar debemos utilizar los wrappers
        //int -> Integer  double -> Double  char -> Character
        
        lista2.add(new Auto("Renault", "Clio", "Rojo"));
        // lista2.add("hola"); error, solo puedo guardar objetos del tipo Auto

        Auto auto1 = (Auto) lista.get(0);
        Auto auto2 = lista2.get(0);

        //copiar los autos de lista a lista2
        lista.forEach(item -> {
            if(item instanceof Auto){
                lista2.add((Auto) item);
            }
        });

        //vemos la lista2 con los agregados
        System.out.println("\nlista2:");
        lista2.forEach(System.out::println);

        //========================================================================

        //Interface Set
        /*
         * La interfaz set provee una lista sin índices.
         * El mismo objeto contenido en la colección, es el índice.
         * Por tal motivo, no admite duplicados.
         */

        //HashSet() es la implementación más veloz y no garantiza un orden específico

        Set<String> setSemana;

        // setSemana = new HashSet<>();
        // setSemana = new LinkedHashSet<>();
        setSemana = new TreeSet<>();

        setSemana.add("Lunes");
        setSemana.add("Lunes");
        setSemana.add("Martes");
        setSemana.add("Miércoles");
        setSemana.add("Jueves");
        setSemana.add("Jueves");
        setSemana.add("Viernes");
        setSemana.add("Sábado");
        setSemana.add("Sábado");
        setSemana.add("Domingo");

        System.out.println("\nsetSemana:");
        setSemana.forEach(System.out::println);

        /*
         * LinkedHashSet
         * No es tan rápida como HashSet, aunque no se va a notar la diferencia en desarrolos chicos.
         * Almacena los elementos en una lista enlazada, esto quiere decir que cuando recorramos la lista,
         * vamos a ver los elementos por orden de entrada.
         */
        
        /*
         * TreeSet
         * La clase TreeSet implementa SortedSet.
         * La clase del Generic debe implementar la interfaz Comparable.
         * TreeSet es una implementación que almacena en un árbol por orden natural.
         * Esto quiere decir que los elementos van a aparecer ordenados. En este caso, al ser
         * del tipo String, van a estar ordenados por orden alfabético.
         * No vamos a necesitar un ordenamiento específico.
         */

        //creamos un set de Autos
        Set<Auto> setDeAutos;

        // setDeAutos = new LinkedHashSet<>();
        setDeAutos = new TreeSet<>();
        /*
         * 
         */


        //agregamos los autos de la lista2 a setDeAutos
        //recorremos la colección con una Lambda 
        // lista2.forEach(item -> setDeAutos.add(item));
        //con referencia a métodos
        // lista2.forEach(setDeAutos::add);
        //con un método de la interfaz Collection
        setDeAutos.addAll(lista2);
        
        //recorro setDeAutos
        System.out.println("\nsetDeAutos:");
        setDeAutos.forEach(System.out::println);

        setDeAutos.add(new Auto("Chevrolet", "Corsita", "rojo"));

        System.out.println("\nsetDeAutos:");
        setDeAutos.forEach(item -> System.out.println(item + "\t" + item.hashCode()));

        //para que 2 objetos sean considerados el mismo objeto, se deben sobreescribir los 
        //métodos equals() y hashCode()

        //===============================================================================

        //Interfaz Queue
        /*
         * La interfaz Queue define operaciones del tipo FIFO (cola)
         * La interfaz Deque es una "double-ended-queue" (cola de doble extremo) y define
         * operaciones del tipo FIFO (cola) y LIFO (pila)
         * FIFO -> First In First Out -> primero en entrar, primero en salir
         * LIFO -> Last Int First Out -> último en entrar, primero en salir
         * 
         * Implementaciones:
         * ArrayDeque -> es una implementación eficiente para el manejo de colas estándard en donde
         * se encolan elementos en la parte de atrás y se desencolan por la parde de adelante.
         * ArrayDeque puede también establer un comportamiento del tipo pila, de acuerdo a los 
         * métodos que esté invocando.
         * PriorityQueue -> organiza los elementos basándose en su orden natural o mediante un 
         * Comparator, lo que permite manejar prioridades, en este caso, el orden de extracción
         * puede no coincidir con el orden de inserción.
         * LinkedList -> también implementa Queue a través de la interfaz Deque y puede utilizarse
         * para representar una cola, aunque ArrayDeque suele ser preferida por su rendimiento.
         */

        System.out.println("\n** Interface Queue **");

        Queue<Auto> colaAutos;

        //le damos una incialización como ArrayDeque en principio para definirlo como una cola
        colaAutos = new ArrayDeque<>();
        //colaAutos = new PriorityQueue<>();
        /*
         * PriorityQueue
         * Permite almacenar elementos de forma que el elemento con mayor prioridad (según el 
         * orden natural o un Comparator definido) siempre se encuentre en la cabeza de la cola.
         * La prioridad se define ya sea mediante el orden natural de los elementos o mendiante
         * un objeto Comparator que se le pase al momento de la creación.
         * En su implementación interna garantiza que el primer elemento sea siempre el de menor
         * valor o de mayor prioridad, según el criterio definido. Pero el resto de la estructura
         * no se encuentra completamente ordenada. Solo garantiza el orden relativo de la cabeza.
         * Al encolar elementos, reorganiza internamente su estructura para mantener la propiedad
         * de que el menor elemento (el de mayor prioridad) esté en la raíz.
         * Al desencolar, se extrae primero la cabeza. Cada extracción reordena su estructura,
         * para colocar al siguiente elemento de prioridad en la cabeza de la cola.
         * Al iterar sobre una PriorityQueue (por ejemplo con un bucle for-each), el orden en el
         * que se recorren los elementos, no es necesariamente el orden natural o el orden de 
         * prioridades. El iterador recorre el arreglo que no está completamente ordenado.
         */


        //el método .offer() permite encolar un elemento
        colaAutos.offer(auto1);
        colaAutos.offer(auto2);
        colaAutos.offer(new Auto("Ford", "Ecosport", "Gris"));
        //existe también el método .add() para agregar, la diferencia es en cómo trabajan internamente
        //el .add() lanza una excepción si la cola está completa
        //offer() en cambio, devuelve un valor booleano que dará falso si no se pudo agregar el elemento
        //(sin lanzar una exepción)

        //Hay clases que implementan la interface Queue y representan estructuras de datos con
        //una capacidad limitada.
        //ArrayBlockingQueue y LinkedBlockingQueue son muy comunes en aplicaciones concurrentes o en
        //sistemas en donde se desea limitar el uso de la memoria.

        //para agregar elementos de una sola vez utilizamos el método addAll()
        colaAutos.addAll(lista2);

        //recorremos el contenido de colaAutos
        System.out.println("contenido de colaAutos:");
        colaAutos.forEach(System.out::println);

        //el método .size() muestra la longitud
        System.out.println("\nLongitud de la cola: " + colaAutos.size());

        //desencolar elementos. Lo hace desde el primero hacia el último
        //el método .poll() desencola elementos, los recupera y los elimina
        System.out.println("\nEliminando elementos...");
        while(!colaAutos.isEmpty()){
            System.out.println(colaAutos.poll());
        }
        //el método .remove() hace lo mismo, pero si la cola está vacía, lanza una excepción
        //en cambio .poll() devuelve un null 
        System.out.println("\nLongitud de la cola: " + colaAutos.size());

        System.out.println("\n#################################################\n");

        //manejo de pila
        //definimos el ArrayDeque como una implementación de Deque para que se pueda comportar como una pila
        Deque<Auto> pilaAutos = new ArrayDeque<>();

        //el método .push() agrega un elemento al tope de la pila (apila)
        pilaAutos.push(new Auto("Citroën", "C4", "Violeta"));

        //agregamos toda una colección
        // pilaAutos.addAll(lista2);

        pilaAutos.push(new Auto("Ford", "Focus", "Verde"));
        pilaAutos.push(new Auto("Ford", "Taunus", "Rojo"));
        pilaAutos.push(new Auto("Chevrolet", "Corsa", "Amarillo"));
        pilaAutos.push(new Auto("Audi", "Coso", "Celeste"));
        pilaAutos.push(new Auto("Michubichi", "Groso", "Blanco"));

        //recorremos pilaAutos
        System.out.println("\nContenido de pilaAutos");
        pilaAutos.forEach(System.out::println);

        System.out.println("\nLongitud de la pila: " + pilaAutos.size() + "\n");

        //el método .pop() elimina elementos de una pila (desapila), también lo recupera
        System.out.println("Eliminando elementos de la pila...");
        while(!pilaAutos.isEmpty()){
            System.out.println(pilaAutos.pop());
        }
        System.out.println("Longitud de la pila: " + pilaAutos.size());

        //=====================================================================

        //pasar un array a una colección

        String[] nombresArray = {"Ana", "Luis", "Maria"};
        List<String> listaNombres = Arrays.asList(nombresArray);
        //crea una vista fijada ("backed") sobre el array. Backed significa que existe
        //en una misma area de almacenamiento subyacente
        //El List resultante tiene un tamaño fijo, no se pueden utilizar los métodos .add()
        //ni remove()
        //Si se modifica un elemento en listaNombres, también cambia el array original y viceversa.

        List<String> listaInmutable = List.of("Ana", "Luis", "Maria");
        //crea una lista inmutable de tamaño fijo. No permite ni add() ni remove() ni set()
        
        List<String> listaNueva = new ArrayList<>();
        Collections.addAll(listaNueva, nombresArray);
        //añade todos los elementos del array a la colección de destino
        //la lista resultante es mutable, se pueden insertar o borrar elementos

        //para pasar a otro tipo de colecciones:
        //a Set
        Set<String> conjunto = new HashSet<>(Arrays.asList(nombresArray));

        //a Queue
        Queue<String> cola = new PriorityQueue<>(Arrays.asList(nombresArray));

        //a Deque
        Deque<String> deque = new ArrayDeque<>(Arrays.asList(nombresArray));









        
    }
}

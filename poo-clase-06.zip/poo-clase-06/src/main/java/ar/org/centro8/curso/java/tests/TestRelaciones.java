package ar.org.centro8.curso.java.tests;

import ar.org.centro8.curso.java.entidades.relaciones.Cuenta;

public class TestRelaciones {
    public static void main(String[] args) {
        System.out.println("** Test de la clase Cuenta **");

        Cuenta cuenta1 = new Cuenta(1, "args");
        System.out.println(cuenta1);

        cuenta1.depositar(50000);
        System.out.println(cuenta1.getSaldo());

        cuenta1.debitar(10000);
        System.out.println(cuenta1.getSaldo());

        Cuenta cuenta2 = new Cuenta(2, "dólares");
        cuenta2.depositar(20000);
        cuenta2.debitar(30000);
        System.out.println(cuenta2.getSaldo());

        System.out.println("** Clase Cuenta funcionando correctamente **");

    }
}

package ar.org.centro8.curso.java.models.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.centro8.curso.java.models.entities.Alumno;

//repository es un estándard de concepto que se refiere a una colección en memoria
//encapsula todo el código de acceso a datos, contiene métodos sencillos como crear, buscar,
//actualizar, borrar, etc.
//Permite pensar en los datos como objetos en una colección en lugar de tablas y sentencias
//SQL. Trabaja directamente con las entidades
public interface I_AlumnoRepository {
    //estos métodos pueden lanzar una SQLException que es una cheked exception,
    //el compilador nos obliga a que capturemos la excepción con un try.catch
    //o que se declare en la firma del método con throws
    void create(Alumno alumno) throws SQLException;
    Alumno findById(int id) throws SQLException;
    List<Alumno> findAll() throws SQLException;
    int update(Alumno alumno) throws SQLException;
    int delete(int id) throws SQLException;
    List<Alumno> findByCurso(int idCurso) throws SQLException;
}

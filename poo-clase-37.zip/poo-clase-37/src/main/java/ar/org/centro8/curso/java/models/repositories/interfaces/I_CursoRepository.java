package ar.org.centro8.curso.java.models.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.centro8.curso.java.models.entities.Curso;
import ar.org.centro8.curso.java.models.enums.Dia;
import ar.org.centro8.curso.java.models.enums.Turno;

public interface I_CursoRepository {
    void create(Curso curso) throws SQLException;
    Curso findById(int id) throws SQLException;
    List<Curso> findAll() throws SQLException;
    int update(Curso curso) throws SQLException;
    int delete(int id) throws SQLException;
    List<Curso> findByDiaAndTurno(Dia dia, Turno turno) throws SQLException;
}

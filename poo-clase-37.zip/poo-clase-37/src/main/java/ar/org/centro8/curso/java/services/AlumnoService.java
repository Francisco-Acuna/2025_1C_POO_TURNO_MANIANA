package ar.org.centro8.curso.java.services;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;

import ar.org.centro8.curso.java.models.entities.Alumno;
import ar.org.centro8.curso.java.models.repositories.interfaces.I_AlumnoRepository;

/*
 * Para este proyecto, agregamos una capa más al clásico MVC: la capa de servicios.
 * Esta estructura es muy utilizada hoy en día porque sigue el principio de Separación
 * de Responsabilidades, lo cual mejora la organización y mantenibilidad del código.
 * La capa modelo se encarga exclusivamente de representar los datos y gestionar el acceso
 * a la base de datos.
 * La capa de vista, se enfoca en la interacción con el usuario: mostrar información y formularios.
 * El controlador solo recibe las solicitudes, prepara los datos para la vista y delega las
 * decisiones importantes.
 * La nueva capa de servicio es la encargada de aplicar las reglas de negocio: validaciones, 
 * cálculos, verificaciones, etc.
 * Así, cada parte del sistema cumple con una función específica, evitando que se mezclen 
 * responsabilidades y permitiendo que el sistema escale o cambie fácilmente en el futuro.
 */

/**
 * Clase de servicio para la entidad Alumno.
 * Encapsula la lógica de negocio relacionada con los alumnos.
 * Actúa como intemediario entre los controladores y los repositorios,
 * asegurando que los controladores sean "delgados" y que la lógica de negocio
 * sea reutilizable y probada en forma aislada.
 */
@Service //indica a Spring que esta clase es un componente de servicio manejado por Spring
public class AlumnoService {

    private final I_AlumnoRepository alumnoRepository;

    public AlumnoService(I_AlumnoRepository alumnoRepository) {
        this.alumnoRepository = alumnoRepository;
    }

    /**
     * Obtiene una lista de todos los alumnos.
     * Acá se podría agregar lógica de negocio adicional antes o después de la llamada al repositorio
     * Como validaciones de permisos, filtros complejos o lo que no sea directamente manejado por
     * el repositorio
     * @return una lista de objetos del tipo Alumno
     * @throws SQLException Si ocurre un error al acceder a la base de datos.
     */
    public List<Alumno> obtenerTodosLosAlumnos() throws SQLException{
        return alumnoRepository.findAll();
        //La lógica actual es simple, solo delega al repositorio.
        //En un caso real, podríamos realizar validaciones, como si el usuario tiene permiso
        //para ver todos los alumnos o si el rol tiene permido para ver todos los campos
    }


    /**
     * Guarda un nuevo alumno o lo actualiza
     * @param alumno -> el objeto alumno a guardar o actualizar
     * @return -> El objeto guardado (con el id generado si es nuevo)
     * @throws SQLException -> Si ocurre un error al acceder a la base de datos
     * @throws IllegalArgumentException -> Si la lógica de negocio detecta un error
     */
    public Alumno guardarAlumno(Alumno alumno) throws SQLException{
        //ejemplo de lógica de negocio en la capa de servicio: validación antes de persistir
        if (alumno.getEdad()<18) { //en el supuesto caso de que los alumnos deban ser mayores
            throw new IllegalArgumentException("La edad del alumno debe ser mayor o igual que 18 años.")
        }
        //si el alumno tiene un id, significa que es una actualización
        if(alumno.getId()!=0){
            alumnoRepository.update(alumno);
            return alumno;
        } else {
            alumnoRepository.create(alumno);
            return alumno;
        }
    }

    /**
     * Busca un alumno por su id
     * @param id -> el id del alumno a buscar
     * @return -> el objeto Alumno encontrado o null si no existe
     * @throws SQLException -> si ocurre un error al acceder a la base de datos.
     */
    public Alumno buscarAlumnoPorId(int id) throws SQLException{
        return alumnoRepository.findById(id);
    }

}

package ar.org.centro8.curso.java.controllers;

import ar.org.centro8.curso.java.models.entities.Curso;
import ar.org.centro8.curso.java.models.enums.Dia;
import ar.org.centro8.curso.java.models.enums.Turno;
import ar.org.centro8.curso.java.services.CursoService; // Importamos el nuevo servicio de Curso

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

@Controller
public class CursoController {

    // Ahora inyectamos el servicio, no el repositorio directamente.
    private final CursoService cursoService;

    // Constructor para la inyección de dependencias.
    public CursoController(CursoService cursoService) {
        this.cursoService = cursoService;
    }

    // Muestra la lista de cursos
    @GetMapping("/cursos")
    public String listarCursos(Model model) {
        try {
            // Delega la obtención de cursos al servicio
            List<Curso> cursos = cursoService.obtenerTodosLosCursos();
            model.addAttribute("cursos", cursos);
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al cargar los cursos: " + e.getMessage());
        }
        return "cursos-list";
    }

    // Muestra el formulario de alta de un nuevo curso
    @GetMapping("/curso/alta")
    public String altaCursoForm(Model model) {
        model.addAttribute("curso", new Curso());
        model.addAttribute("dias", Arrays.asList(Dia.values()));
        model.addAttribute("turnos", Arrays.asList(Turno.values()));
        return "curso-alta";
    }

    // Procesa el formulario de alta de un curso
    @PostMapping("/curso/guardar")
    public String guardarCurso(@ModelAttribute("curso") Curso curso, Model model) {
        try {
            // Delega la lógica de guardar al servicio.
            // La lógica para `setActivo(true)` por defecto en nuevos cursos ahora reside en el servicio.
            cursoService.guardarCurso(curso);
            return "redirect:/cursos";
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al guardar el curso: " + e.getMessage());
            model.addAttribute("dias", Arrays.asList(Dia.values()));
            model.addAttribute("turnos", Arrays.asList(Turno.values()));
            return "curso-alta";
        }
    }

    // Muestra el formulario de edición de un curso
    @GetMapping("/curso/editar")
    public String editarCursoForm(@RequestParam("id") int id, Model model) {
        try {
            // Delega la búsqueda al servicio
            Curso curso = cursoService.buscarCursoPorId(id);
            if (curso != null) {
                model.addAttribute("curso", curso);
                model.addAttribute("dias", Arrays.asList(Dia.values()));
                model.addAttribute("turnos", Arrays.asList(Turno.values()));
                return "curso-editar";
            } else {
                return "redirect:/cursos";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al cargar el curso para editar: " + e.getMessage());
            return "redirect:/cursos";
        }
    }

    // Procesa el formulario de edición de un curso
    @PostMapping("/curso/actualizar")
    public String actualizarCurso(@ModelAttribute("curso") Curso curso, Model model) {
        try {
            // Delega la actualización al servicio (el mismo método `guardarCurso` puede manejarlo)
            cursoService.guardarCurso(curso);
            return "redirect:/cursos";
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al actualizar el curso: " + e.getMessage());
            model.addAttribute("dias", Arrays.asList(Dia.values()));
            model.addAttribute("turnos", Arrays.asList(Turno.values()));
            return "curso-editar";
        }
    }

    // Eliminar un curso
    @GetMapping("/curso/eliminar")
    public String eliminarCurso(@RequestParam("id") int id, Model model) {
        try {
            // Delega la eliminación al servicio
            cursoService.eliminarCurso(id);
            return "redirect:/cursos";
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al eliminar el curso: " + e.getMessage());
            try {
                // Si falla la eliminación, recargar la lista de cursos a través del servicio
                model.addAttribute("cursos", cursoService.obtenerTodosLosCursos());
            } catch (SQLException ex) {
                ex.printStackTrace();
                model.addAttribute("error", "Error al recargar cursos después de eliminación fallida: " + ex.getMessage());
            }
            return "cursos-list";
        }
    }

    // Buscar cursos por día y turno
    @GetMapping("/cursos/buscar")
    public String buscarCursosPorDiaTurno(@RequestParam(value = "dia", required = false) Dia dia,
                                       @RequestParam(value = "turno", required = false) Turno turno,
                                       Model model) {
        try {
            List<Curso> cursos;
            if (dia != null && turno != null) {
                // Delega la búsqueda filtrada al servicio
                cursos = cursoService.buscarCursosPorDiaYTurno(dia, turno);
            } else {
                // Delega la búsqueda de todos al servicio
                cursos = cursoService.obtenerTodosLosCursos();
            }
            model.addAttribute("cursos", cursos);
            model.addAttribute("dias", Arrays.asList(Dia.values()));
            model.addAttribute("turnos", Arrays.asList(Turno.values()));
            model.addAttribute("selectedDia", dia);
            model.addAttribute("selectedTurno", turno);
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al buscar cursos: " + e.getMessage());
        }
        return "cursos-list";
    }
}
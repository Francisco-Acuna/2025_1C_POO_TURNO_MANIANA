package ar.org.centro8.curso.java.controllers;

import ar.org.centro8.curso.java.models.entities.Alumno;
import ar.org.centro8.curso.java.models.entities.Curso;
import ar.org.centro8.curso.java.services.AlumnoService; 
import ar.org.centro8.curso.java.services.CursoService;   

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.sql.SQLException;
import java.util.List;

@Controller
public class AlumnoController {

    // Inyectamos los servicios, no los repositorios directamente.
    // El controlador delega la lógica de negocio a los servicios.
    private final AlumnoService alumnoService;
    private final CursoService cursoService;

    // Constructor para la inyección de dependencias.
    // Spring inyectará automáticamente las instancias de AlumnoService y CursoService.
    public AlumnoController(AlumnoService alumnoService, CursoService cursoService) {
        this.alumnoService = alumnoService;
        this.cursoService = cursoService;
    }


    // Método para mostrar la lista de alumnos
    @GetMapping("/") //Anotación de Spring MVC que indica que el método se ejecutará cuando el navegador haga una petición GET a la raíz del sitio (/).
    //Una petición GET es cuando el navegador pide una página o recurso.
    //La raíz (/) es la dirección base del sitio, sin ninguna ruta adicional.
    // Cuando utilizamos @GetMapping("/"), le estamos diciendo a Spring: que cuando el usuario entre a la página principal (/),  se ejecutá este método.
    //El método se llama home, pero puede llevar cualquier otro nombre: "inicio", "bienvenida", "principal".
    //Por convención se suele llamar home porque representa la página principal del sitio.
    //Para este proyecto utilizaremos la vista de los alumnos como home para mostrar el funcionamiento completo del mvc con jdbc
    public String home(Model model) {
        //el String que retorna será el nombre de la vista a renderizar (Transformar datos o instrucciones en algo visible en pantalla.)
        //En este caso renderizar es construir la página completa con los datos que le damos y mostrarla en el navegador.
        //Model es una interfaz de Spring MVC. Representa un conjunto de atributos generados como key-value que vive solo durante la petición actual
        //Es un objeto que Spring inyecta para que el controlador envíe datos a la vista.
        try {
            // Delega la obtención de alumnos al servicio
            List<Alumno> alumnos = alumnoService.obtenerTodosLosAlumnos();
            model.addAttribute("alumnos", alumnos);
            //los parámetros son key -> "alumnos" y value -> alumnos. La llave es la clave con la que la vista buscará el dato
            //y el valor es el objeto real que se quiere exponer
            //La vista usa ${key} que en este caso sería el primer "alumnos" para acceder a cada dato y renderizar la página.

            // También cargamos los cursos para el dropdown de búsqueda
            //un dropdown es un menú desplegable que permite al usuario elegir una opción para filtrar o buscar algo
            List<Curso> cursos = cursoService.obtenerTodosLosCursos();
            model.addAttribute("cursos", cursos);
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al cargar los alumnos: " + e.getMessage());
        } catch (Exception e) { // Capturar otras posibles excepciones de la capa de servicio
            e.printStackTrace();
            model.addAttribute("error", "Ha ocurrido un error inesperado: " + e.getMessage());
        }
        return "index";
    }

    // Método para mostrar el formulario de alta de un nuevo alumno
    @GetMapping("/alumno/alta")
    public String altaAlumnoForm(Model model) {
        model.addAttribute("alumno", new Alumno());
        try {
            // Delega la obtención de cursos al servicio
            List<Curso> cursos = cursoService.obtenerTodosLosCursos();
            model.addAttribute("cursos", cursos);
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("errorCursos", "Error al cargar los cursos: " + e.getMessage());
        }
        return "alumno-alta";
    }

    // Método para procesar el formulario de alta de un alumno
    @PostMapping("/alumno/guardar")
    //GET se usa para pedir información (por ejemplo, ver una lista).
    //POST se usa para enviar información que modifica el sistema (como guardar, crear, actualizar o eliminar algo).
    //En este caso vamos a utilizar un formulario para dar de alta un nuevo alumno, eso implica modificar la base de datos, por eso se usa POST.
    public String guardarAlumno(@ModelAttribute("alumno") Alumno alumno, Model model) {
        //@ModelAttribute es una anotación de Spring que sirve para indicar que un objeto debe ser creado y llenado automáticamente
        //con los datos enviados desde la vista.
        //Spring enlaza o vincula (binding) los campos del formulario a un objeto Alumno
        try {
            // Delega la lógica de guardar al servicio
            alumnoService.guardarAlumno(alumno);
            return "redirect:/";
            //Después de un POST, se redirecciona al usuario con GET a la raíz /.
            //Evita que al presionar F5 se repita el envío del formulario.
            //Actualiza la barra del navegador a la página principal.

            //En este primer try, se intenta guardar el alumno (insertar en la base). No se necesita cargar cursos acá.
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al guardar el alumno: " + e.getMessage());
            //en el catch queremos volver a mostrar la página alumno-alta.html para que el usuario corrija el error. 
            //Pero esa vista necesita la lista de cursos para mostrar el combo.
            try {
                //Aunque la carga de cursos funcionó antes, cuando queremos volver a mostrar la vista, tenemos que volver 
                //a consultarlos, y esa segunda consulta también puede fallar (aunque sea raro).
                //Por eso tenemos que volver a armar otra estructura try catch
                model.addAttribute("cursos", cursoService.obtenerTodosLosCursos());
            } catch (SQLException ex) {
                ex.printStackTrace();
                model.addAttribute("errorCursos", "Error al recargar los cursos: " + ex.getMessage());
            }
            return "alumno-alta";
        } catch (IllegalArgumentException e) { // Captura excepciones de validación de negocio del servicio
            e.printStackTrace();
            model.addAttribute("error", e.getMessage()); // Muestra el mensaje de error de validación
            try {
                model.addAttribute("cursos", cursoService.obtenerTodosLosCursos());
            } catch (SQLException ex) {
                ex.printStackTrace();
                model.addAttribute("errorCursos", "Error al recargar los cursos: " + ex.getMessage());
            }
            return "alumno-alta";
        }
    }

    // Método para eliminar un alumno
    @GetMapping("/alumno/eliminar")
    public String eliminarAlumno(@RequestParam("id") int id, Model model) {
        //@RequestParam("id") Toma el valor del parámetro id que viene en la URL (ej: ?id=3) y lo guarda en la variable id.
        try {
            // Delega la eliminación al servicio
            alumnoService.eliminarAlumno(id);
            return "redirect:/"; //redirecciona a la página principal, a la raíz, generando una nueva petición GET /
            //actualiza la vista por completo
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al eliminar el alumno: " + e.getMessage());
            //Después del error, queremos mostrar nuevamente el listado de alumnos en la página de inicio (index.html), 
            //pero para eso necesitamos recargar la lista.
            //Esta consulta también podría fallar (por ejemplo, si la base de datos sigue caída).
            //Por eso se maneja en un try-catch separado, para no perder el control del flujo si esa parte también falla.
            try {
                model.addAttribute("alumnos", alumnoService.obtenerTodosLosAlumnos());
            } catch (SQLException ex) {
                ex.printStackTrace();
                model.addAttribute("error", "Error al recargar alumnos después de eliminación fallida: " + ex.getMessage());
            }
            return "index";
            //Si ocure un eror, no se redirige, se devuelve la vista del index directamente.
            //En este caso, se carga la vista pero sin generar una nueva petición ni modificar la URL. Los datos cargados se mantienen en la vista
        }
    }

    // Método para mostrar el formulario de edición de un alumno
    @GetMapping("/alumno/editar")
    public String editarAlumnoForm(@RequestParam("id") int id, Model model) {
        //vamos a recibir un parámetro para la consulta en la URL (por GET), ese parámetro va a ser el id
        //una request es una solicitud y proviene del navegador, por ejemplo cuando el usuario escribe una url y presiona enter
        //o cuando envía un formulario con el botón "enviar" o cuando hace click en un enlace. 
        //@RequestParam es una anotación de Spring MVC que se utiliza para extraer un parámetro de la URL y asignarlo a una variable
        //El "id" es el value, es decir el valor del atributo. Cuando es el único parámetro, no hace falta aclarar que es el value.
        try {
            // Delega la búsqueda al servicio
            Alumno alumno = alumnoService.buscarAlumnoPorId(id);
            if (alumno != null) {
                model.addAttribute("alumno", alumno);
                List<Curso> cursos = cursoService.obtenerTodosLosCursos();
                model.addAttribute("cursos", cursos);
                return "alumno-editar"; //es la vista que se tiene que cargar para editar a un alumno
            } else {
                return "redirect:/"; // Si el alumno no existe, redirigir a la página principal
            }
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al cargar el alumno para editar: " + e.getMessage());
            return "redirect:/"; //se redirige, porque no tenés información para continuar.
        }
    }

    // Método para procesar el formulario de edición de un alumno
    @PostMapping("/alumno/actualizar")
    public String actualizarAlumno(@ModelAttribute("alumno") Alumno alumno, Model model) {
        try {
            // Delega la actualización al servicio
            alumnoService.guardarAlumno(alumno); // El servicio maneja si es create o update
            return "redirect:/";
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al actualizar el alumno: " + e.getMessage());
            try {
                model.addAttribute("cursos", cursoService.obtenerTodosLosCursos());
            } catch (SQLException ex) {
                ex.printStackTrace();
                model.addAttribute("errorCursos", "Error al recargar los cursos: " + ex.getMessage());
            }
            return "alumno-editar";
        } catch (IllegalArgumentException e) { // Captura excepciones de validación de negocio del servicio
            e.printStackTrace();
            model.addAttribute("error", e.getMessage());
            try {
                model.addAttribute("cursos", cursoService.obtenerTodosLosCursos());
            } catch (SQLException ex) {
                ex.printStackTrace();
                model.addAttribute("errorCursos", "Error al recargar los cursos: " + ex.getMessage());
            }
            return "alumno-editar";
        }
    }

    // Método para buscar alumnos por curso (ejemplo de filtro)
    @GetMapping("/alumnos/buscarPorCurso")
    public String buscarAlumnosPorCurso(@RequestParam(value = "idCurso", required = false) Integer idCurso, Model model) {
        //se lee el atributo "idCurso" que viene por GET en  la URL. En este caso, como hay dos parámetros, tenemos que indicar explícitamente
        //que ese atributo es el value. El segundo parámetro indica que el value no es obligatorio en la URL. 
        //Se declara una variable llamada idCurso de tipo Integer. Se usa Integer (la clase envoltorio) en lugar de int (el tipo primitivo) porque 
        //Integer puede ser null, lo cual es necesario cuando required = false.
        try {
            List<Alumno> alumnos;
            if (idCurso != null && idCurso != 0) {
                // Delega la búsqueda filtrada al servicio
                alumnos = alumnoService.buscarAlumnosPorCurso(idCurso);
            } else {
                // Delega la búsqueda de todos al servicio
                alumnos = alumnoService.obtenerTodosLosAlumnos();
            }
            model.addAttribute("alumnos", alumnos);
            List<Curso> cursos = cursoService.obtenerTodosLosCursos();
            model.addAttribute("cursos", cursos);
            model.addAttribute("selectedCursoId", idCurso);
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al buscar alumnos: " + e.getMessage());
        }
        return "index";
    }
}
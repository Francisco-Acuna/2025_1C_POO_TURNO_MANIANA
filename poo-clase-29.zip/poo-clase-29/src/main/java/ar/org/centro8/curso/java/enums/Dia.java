package ar.org.centro8.curso.java.enums;

// Enum es un tipo especial de clase que define un conjunto fijo de constantes con nombre
// Se utiliza para presentar valores limitados y conocidos de antemano
public enum Dia {
    LUNES,
    MARTES,
    MIERCOLES,
    JUEVES,
    VIERNES;

//Un Enum es como una lista de opciones fijas: en vez de pasar el texto "LUNES", se utiliza
//Dia.Lunes y Java impide poner cualquier otro valor que no exista en esa lista
//Cada valor dentro de un Enum son constantes que representan una instancia de la clase Enum
//Estos objetos pueden poseer atributos, para ello debe crearse un constructor privado que le
//permita asignar el valor como estado. Es privado para que desde afuera no se puedan crear más
//objetos del enum. Al declarar los objetos dentro del enum se le pasan los parámetros como 
//valores de sus atributos.
//Implementan Serializable y Comparable automáticamente
//No pueden extender de otra clase, pero pueden implementar interfaces
//La interfaz Serializable marca una clase como capaz de convertirse en una secuencia de bytes
}

package ar.org.centro8.curso.java.enums;

public enum EstadoPedidoPrueba {
    PENDIENTE("Pendiente de envío"),
    EN_PROGRESO("En proceso de preparación"),
    ENTREGADO("Entregado al cliente");

    private final String descripcion;

    private EstadoPedidoPrueba(String descripcion){
        this.descripcion = descripcion;
    }

    @Override
    public String toString(){
        return descripcion;
    }
}

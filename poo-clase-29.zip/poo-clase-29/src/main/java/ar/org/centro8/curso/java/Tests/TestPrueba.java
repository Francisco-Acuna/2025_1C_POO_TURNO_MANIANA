package ar.org.centro8.curso.java.Tests;

import ar.org.centro8.curso.java.enums.EstadoPedidoPrueba;

public class TestPrueba {
    public static void main(String[] args) {
        System.out.println(EstadoPedidoPrueba.EN_PROGRESO);
    }
}

public class Clase01 {
    public static void main(String[] args) {
        /*
         * Instituto: Centro de Formación Profesional N°8
         * Curso: Programación Orientada a Objetos
         * Lenguaje: Java
         * Cursada: lunes, martes y miércoles de 10 a 13.30hs.
         * Profesor: Francisco Acuña
         * Email: franciscoacuna.centro8@gmail.com
         * Repositorio: https://github.com/Francisco-Acuna/2025_1C_POO_TURNO_MANIANA
         * Softwares:
         *          - JDK (sugerido 21 LTS) -> https://www.oracle.com/java/technologies/downloads/#jdk21-windows
         *          - Visual Studio Code -> https://code.visualstudio.com/
         *          - Extensión de VSC -> Extension Pack for Java (by Microsoft)
         *          - MySQL y Workbench -> https://dev.mysql.com/downloads/installer/
         */

        //comentarios en línea

        /*
         * bloque
         * de
         * comentarios
         */

        /**
         * comentarios del tipo
         * JavaDoc
         * son en bloque
         * van antes de las definiciones de clases y métodos
         */

        //etiquetas en comentarios

        //TODO: indica tareas pendientes por implementar o finalizar

        //FIXME: señalan errores o problemas que deben ser corregidos

        //instalar extensión TODO TREE (by Gruntfuggly)

        //impresión por consola
        System.out.println("Hola Mundo!"); //esto es una sentencia

        //ctrl + k + ctrl + s  -> atajos de teclado

        //declaración de variable:
        int variable; //declaración de variable con su tipo de dato e identificador
        variable = 10; //asignación de valor a la variable
        int variable2 = 10; //declaración y asignación de valor en una misma línea
        int variable3=10, variable4=20, variable5=30; //declaración y asignación múltiple

        /*
         * Java es un lenguaje fuertemente tipado, por lo cual, se deben respetar
         * ciertos lineamientos:
         * No se puede asignar otro tipo de dato como valor a una variable ya declarada
         * No puedo cambiar el tipo de dato de una variable ya declarada
         * No puedo crear otra variable con el mismo nombre.
         * Una variable debe tener una única declaración.
         * Una variable puede tener innumerables valores, pero siempre del 
         * mismo tipo de dato.
         */

        // *** Tipos de datos primitivos ***

        //byte - ocupa 1 byte y representa un número entero entre -128 y 127
        byte variableByte = 100;
        System.out.println(variableByte);

        //short - ocupa 2 bytes y representa un número entero entre -32.768 y 32.767
        short variableShort = 14265;
        System.out.println(variableShort);

        //int - ocupa 4 bytes y representa un número entero entre -2.147.483.648 y 2.147.483.647
        int variableInt = 389_485_738;
        System.out.println(variableInt);

        //long - ocupa 8 bytes y representa un número entero muy grande
        //que va desde -2 elevado a la 63 hasta el 2 elevado a la 63 -1 
        long variableLong = 64654684651864618L; //debe llevar una L al final de la literal
        System.out.println(variableLong);

        //float - ocupa 4 bytes y tiene alrededor de 6-7 dígitos de precisión total
        float variableFloat = 2416.45f; //deben llevar una f al final de la literal
        //los decimales se separan con punto .
        System.out.println(variableFloat);

        //double - ocupa 8 bytes y tiene alrededor de 15-16 dígitos de precisión total
        double variableDouble= 1235.45;
        System.out.println(variableDouble);

        //boolean - almacena solo 2 valores posible (true y false)
        boolean variableBoolean = true;
        System.out.println(variableBoolean);

        //char - ocupa 2 bytes y almacena un número entero que
        //representa un caracter de la tabla unicode
        //la tabla UNICODE es un estandar de condificación a nivel mundial
        char variableChar = 65;
        System.out.println(variableChar);
        variableChar = 'f';
        System.out.println(variableChar);

        //** String **
        //no es un tipo de dato primitivo, es una clase
        //representa una cadena de caracteres
        String variableString = "Hola Mundo!";
        System.out.println(variableString);

        //tipos de datos var (inferencia de tipos)
        //aparecen a partir del JDK 10
        //no es un tipo de datos en si mismo. Es una palabra clave que indica
        //al compilador, que infiera el tipo de dato, a partir de la primera
        //asignación de valor
        var var1 = 100; //int
        var var2 = 'c'; //char
        var var3 = "c"; //String
        var var4 = 4.35f; //float
        var var5 = 4.35; //double
        //este tipo de dato solo puede ser usado en variables locales
        //no puede ser usado como parámetro de método ni como atributo de clase

        //concatenación de cadenas
        //operador +
        String nombre = "Laura";
        System.out.println("Hola " + nombre);

        //método String.format()
        //permite formatear cadenas de manera similar a printf en C
        int edad = 24;
        String mensaje = String.format("Hola, mi nombre es %s y tengo "+
                                        "%d años.", nombre, edad);
        System.out.println(mensaje);
        /*
         * %s -> cadenas de texto
         * %d -> números enteros
         * %f -> números decimales
         * %n -> salto de línea
         */

        //método System.out.printf()
        //se utiliza para imprimir directamente con formato
        System.out.printf("Hola, mi nombre es %s y tengo %d años."
                            , nombre, edad); 

        System.out.println();

        //*** operadores ***

        //Operadores aritméticos
        /*
         * + suma
         * - resta
         * * multiplicación
         * / división
         * % módulo o resto de la división
         * Son operadores binarios porque necesitan de 2 operandos
         * Los operandos son numéricos y el resultado es numérico.
         */

        //Operadores de asignación
        /*
         * =  asignación
         * += suma y asignación
         * -= resta y asignación
         * *= multiplicación y asignación
         * /= división y asignación
         * %= resto y asignación
         * Son operadores binarios.
         * Asignan el valor a una variable y se la modifican utilizando una expresión.
         */

        //Operadores incrementales y decrementales
        /*
         * ++ incrementa en 1 el valor de la variable
         * -- decremente en 1 el valor de la variable
         * Puede utilizarse de dos formas:
         * prefijo (++x o --x): la variable se modifica antes de que se use
         * su valor en la expresión.
         * postfijo (x++ o x--): la variable se modifica después de que se use
         * su valor en la expresión.
         * Son operadores unarios, trabajan con un solo operador.
         */

        //Operadores relacionales
        /*
         * >  mayor
         * <  menor
         * >= mayor o igual
         * <= menor o igual
         * == igual
         * != distinto
         * Son operadores binarios.
         * Los operandos son numéricos y el resultado booleano.
         */

        //Operadores lógicos
        /*
         * & and (y lógico)
         * | or (o lógico)
         * ! not (negación)
         * Los operandos son booleanos.
         * El resultado es booleano.
         * Utilizamos dos operadores en cada operación.
         */

        boolean log = true && false;
        System.out.println(log);

        /*
         * Un solo operador lógico | o & evalúa ambas condiciones
         * Al utilizar dos operadores || o && si una condición determina el 
         * valor de verdad, no evalía la condición que sigue.
         */


    }
}

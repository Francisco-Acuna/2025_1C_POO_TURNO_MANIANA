package ar.org.centro8.curso.java.Tests;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import ar.org.centro8.curso.java.entidades.Auto;

public class TestCollections {
    public static void main(String[] args) {
        //List
        /*
         * La interface List representa una lista con índices, emula a un vector.
         * List es la única que tiene métodos definidos con índice.
         * ArrayList es una lista del tipo vector que tiene por dentro un comportamiento
         * que emula a un vector, pero que no es un vector, ya que es completamente dinámico.
         * LinkedList tiene todo el comportamiento heredado de List, pero internamente, usa
         * una lista enlazada.
         * La clase Vector implementa List, no son los vectores que hemos visto hasta ahora.
         * Es una implementación de List que internamente utiliza la tecnología de vectores.
         * No es recomendado su uso, ya que es tecnología antigua y poco performante.
         * ArrayList es una lista tipo vector y LinkedList es una lista enlazada.
         * Hay una mínima diferencia entre las dos, y tiene que ver con la performance.
         * Un ArrayList es más veloz para recorrer elementos.
         * Un LinkedList es más veloz para agregar y eliminar elementos.
         */

        List lista;

        lista = new ArrayList();

        //.add() método para agregar elementos a un List
        lista.add(new Auto("Peugeot", "308", "azul"));
        lista.add(new Auto("Chevrolet", "Corsa", "rojo"));
        lista.add("hola");
        lista.add(80);
        lista.add(23.45);

        //recorrido de la lista con índices
        for (int i = 0; i < lista.size(); i++) {
            System.out.println(lista.get(i));
            //el método .get() devuelve el elemento que se encuentre en el 
            //índice que le pasamos como parámetro
        }
        //el método .size() devuelve la longitud de un List

        //el método .remove() elimina un elemento
        lista.remove(4); //elimina el elemento del índice 4

        //recorrido con for-each
        for(Object o:lista) System.out.println(o);

        /*
         * Interface Iterable
         * Iterable es el padre de todas las interfaces en el framework collections.
         * Dentro de Iterable se encuentra definido foreach(), es un método default.
         * Este método realiza un recorrido, la idea es que no tengamos nosotros que
         * recorrer la lista utilizando una estructura repetitiva, si no, que sea la 
         * misma lista, la que se autorrecorra. 
         */

         System.out.println("\nRecorrido con foreach()");
         lista.forEach(item -> System.out.println(item));
         /*
          * el método foreach() recibe un objeto del tipo Consumer que define qué
          operación se ejecutará sobre cada elemento de la colección.
          Consumer es un interfaz funcional cuyo propósito es consumir un valor. 
          Representa una operación que recibe un argumento del tipo T y no devuelve nada.
          T no es un tipo concreto de dato, es un símbolo que representa un tipo genérico.
          El método foreach() por lo general se implementa con una expresión Lambda.
          Las Lambdas Expressions son funciones anónimas que aparecieron a partir del 
          JDK 8. 
          Una función anónima es una porción de código que no tiene nombre y se define
          en el sitio donde se va a utilizar. Se utilizan para simplificar código.
          */
         
        System.out.println();
        //si queremos utilizar más de una sentencia, tenemos que abrir un bloque de llaves
        lista.forEach(item -> {
            System.out.println(item);
            System.out.println("*");
        });

        //Method reference (referencia de métodos)
        System.out.println("\nRecorrido con foreach() simplificado:");
        lista.forEach(System.out::println);
        //si solo vamos a escribir una única sentencia, podemos omitir el uso del iterador
        //con el operador 4 puntos :: le estamos indicando a Java que el ítem implícito
        //lo coloque como argumento del método.

        //Recorrido con ListIterator
        /*
         * ListIterator es una interfaz especializada en recorrer colecciones que implementan
         * List. A diferencia del Iterador simple (Iterator) o del método foreach de Iterable,
         * ListIterator ofrece funcionalidades adicionales:
         * - Recorrido bidireccional: Permite avanzar y retroceder sobre las listas.
         * - Tiene acceso a índices.
         * - Permite eliminar, reemplazar y agregar elementos durante la iteración.
         */

        List nombres = new ArrayList();
        nombres.add("Ricardo");
        nombres.add("Jenny");
        nombres.add("Carlos");
        nombres.add("Ana");
        nombres.add("Marcela");

        //obtenemos el ListIterator de la lista
        ListIterator<String> li = nombres.listIterator();

        //recorrido hacia adelante
        System.out.println("\nRecorrido hacia adelante del ListIterator");
        while(li.hasNext()){ //comprueba si queda al menos un elemento más por recorrer
            int indice = li.nextIndex(); //índice del elemento que se va a devolver
            String nombre = li.next(); //devuelve el siguiente elemento
            System.out.println("Índice " + indice + ": " + nombre);
        }

        //recorrido para atrás
        System.out.println("\nRecorrido hacia atrás:");
        while(li.hasPrevious()){
            int indice = li.previousIndex();
            String nombre = li.previous();
            System.out.println("Índice: " + indice + ": " + nombre);
        }

        //reemplazar elementos
        while(li.hasNext()){
            String nombre = li.next();
            if(nombre.equals("Carlos")){
                li.set("David"); //Reemplaza Carlos por David
            }
        }

        System.out.println("\nLista después de modificar 'Carlos', por 'David'" + nombres);
        
        //agregar elementos
        li = nombres.listIterator(); //reinicio la posición del cursor
        while(li.hasNext()){
            String nombre = li.next();
            if(nombre.equals("Ana")){
                li.add("Juan"); //agrega "Juan" inmediatamente después de "Ana"
            }
        }

        System.out.println("\nLista después de agregar a 'Juan' luego de 'Ana': " + nombres);

        //eliminar elementos
        li = nombres.listIterator();
        while(li.hasNext()){
            String nombre = li.next();
            if(nombre.equals("Jenny")){
                li.remove(); //elimina el elemento
            }
        }

        System.out.println("\nLista después de eliminar a 'Jenny': " + nombres);
    }
}

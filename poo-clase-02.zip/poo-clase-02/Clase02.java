import java.util.Scanner;

public class Clase02 {
    public static void main(String[] args) {
        
        //*** Estructuras ***

        //condicionales

        //if
        int numero1 = 10;
        int numero2 = 20;

        if(numero1>numero2) System.out.println("El número1 es mayor que el número2");
        //if en línea, si solo se ejecuta una única sentencia en el cuerpo del if

        if(numero1>numero2){
            System.out.println("El número1 es mayor que el número2");
            int suma = numero1 + numero2;
            System.out.println("La suma de ambos números es igual a " + suma);
        }
        //como se ejecutan más de una sentencia, va en bloque (entre llaves)

        //if-else
        if(numero1>numero2){
            System.out.println("El número1 es mayor que el número2");
            System.out.println("Se ejecutan varias sentencias");
        }else {
            System.out.println("El número1 no es mayor que el número2");
            System.out.println("Se ejecutan varias sentencias.");
        }

        //if-else en cascada (if-else if-else)
        if(numero1>numero2){
            System.out.println("El número1 es mayor que el número2");
        }else if(numero1<numero2){
            System.out.println("El número1 es menor que el número2");
        }else{
            System.out.println("Ambos números son iguales.");
        }

        //if-else anidado
        int edad = 18;
        boolean tienePasaporte = true;
        if(tienePasaporte){
            if(edad>=18){
                System.out.println("Puede viajar solo.");
            }else{
                System.out.println("Debe viajar acompañado,");
            }
        }else{
            System.out.println("No puede viajar.");
        }

        //operador ternario
        //condición ? valorSiVerdadero : valorSiFalso
        String mensaje = (edad>=18) ? "Es mayor de edad" : "Es menor de edad";
        System.out.println(mensaje);

        //Estructura switch
        int dia = 6;
        switch(dia){
            case 1: System.out.println("El día es lunes"); break;
            case 2: System.out.println("El día es martes"); break;
            case 3: System.out.println("El día es miércoles"); break;
            case 4: System.out.println("El día es jueves"); break;
            case 5: System.out.println("El día es viernes"); break;
            case 6: System.out.println("El día es sábado"); break;
            case 7: System.out.println("El día es domingo"); break;
            default: System.out.println("El día no es válido"); 
        }

        switch(dia){
            case 1,2,3,4,5: System.out.println("Es un día se semana"); break;
            case 6,7: System.out.println("Es fin de semana"); break;
            //el default es opcional. 
        }

        //rule switch
        //aparece a partir del JDK 14
        //se reemplazan los : por las ->
        //desaparecen los break
        //se puede utilizar la estructura como una expresión
        String diaSemana = switch(dia){
            case 1 -> "Lunes";
            case 2 -> "Martes";
            case 3 -> "Miércoles";
            case 4 -> "Jueves";
            case 5 -> "Viernes";
            case 6 -> "Sábado";
            case 7 -> "Domingo";
            default -> "Día inválido";
        };
        System.out.println(diaSemana);

        //*** Estructuras repetitivas ***

        //while
        int contador = 1;
        while(contador<=10){
            System.out.println(contador);
            contador++;
        }

        //do-while con break y continue
        int numero = 0;
        int suma = 0;
        Scanner teclado = new Scanner(System.in);

        System.out.println("Se sumarán los números enteros, pares, positivos");
        System.out.println("Siempre y cuando la suma no supere los 100");
        do{
            System.out.println("Ingrese un número entero o el 0 para salir");
            numero = teclado.nextInt();
            if(numero%2 !=0) continue;
            if(numero > 0) suma += numero;
            if(suma > 100) break;
        }while(numero!=0);
        System.out.println("La suma de los números enteros pares positivos es igual a " + suma);

        //for
        for (int i = 1; i < 5; i*=2) {
            System.out.print("Hola");
        }


    }
}

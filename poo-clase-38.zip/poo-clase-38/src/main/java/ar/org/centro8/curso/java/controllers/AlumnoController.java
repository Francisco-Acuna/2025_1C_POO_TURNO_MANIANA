package ar.org.centro8.curso.java.controllers;

import java.sql.SQLException;
import java.util.List;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import ar.org.centro8.curso.java.models.entities.Alumno;
import ar.org.centro8.curso.java.models.entities.Curso;
import ar.org.centro8.curso.java.services.AlumnoService;
import ar.org.centro8.curso.java.services.CursoService;

public class AlumnoController {
    //inyectamos los servicios, no los repositorios directamente
    private final AlumnoService alumnoService;
    private final CursoService cursoService;

    //constructor para la inyección de dependencias
    //Spring inyectará automáticamente las instancias de AlumnoService y CursoService
    public AlumnoController(AlumnoService alumnoService, CursoService cursoService){
        this.alumnoService=alumnoService;
        this.cursoService=cursoService;
    }

    //método para mostrar la lista de alumnos
    @GetMapping("/") //Anotación de Spring MVC que indica que el método se ejecutará cuando el
    //navegador haga una petición GET a la raíz del sitio
    //Una petición GET es cuando el navegador pide una página o recurso.
    //La raíz "/" es la dirección base del sitio, sin ninguna ruta adicional.
    //Cuando utilizamos @GetMapping, le estamos diciendo a Spring que cuando el usuario ingrese
    //a la página principal, se ejecute este método.
    //El método se llama home() porque representa la página principal del sitio, pero podría 
    //llamarse de cualquier otra manera. Por ej, "bienvenida", "inicio", "principal", etc.
    //Para este proyecto, utilzaremos la vista de los alumnos como home para mostrar el 
    //funcionamiento completo del MVC con JDBC.
    public String home(Model model) {
        //El String que devuelve es el nombre de la vista que va a renderizar
        //renderizar es transformar datos o instrucciones en algo visible en pantalla.
        //En este caso, renderizar es construir la página completa con los datos que le damos y
        //mostrarla en el navegador
        //Model es una interfaz de Spring MVC. Representa un conjunto de atributos generados como
        //key-value que vive solo durante la petición actual.
        //Es un objeto que Spring inyecta para que el controlador envíe los datos a la vista.
        try {
            //delegamos la obtención de los alumnos al servicio
            List<Alumno> alumnos = alumnoService.obtenerTodosLosAlumnos();
            model.addAttribute("alumnos", alumnos);
            //los parámetros son key->"alumnos" y value->alumnos La llave es la clave con la que 
            //la vista, buscará el dato. Y el valor es el objeto real que se quiere exponer.
            //También vamos a cargar los cursos, para el dropdown de búsqueda
            //Un dropdown es un menú desplegable que permite al usuario elegir una opción
            //para filtrar o buscar algo.
            List<Curso> cursos = cursoService.obtenerTodosLosCursos();
            model.addAttribute("cursos", cursos);
        } catch (SQLException e){
            e.printStackTrace();
            model.addAttribute("error", "Error al cargar los alumnos: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("error", "Ha ocurrido un error inesperado: " + e.getMessage());
        }
        return "index";
    }


}

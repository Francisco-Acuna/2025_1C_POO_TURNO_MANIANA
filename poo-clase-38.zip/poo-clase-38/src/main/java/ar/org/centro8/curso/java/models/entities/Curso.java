package ar.org.centro8.curso.java.models.entities;

import ar.org.centro8.curso.java.models.enums.Dia;
import ar.org.centro8.curso.java.models.enums.Turno;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Curso {
    /*
    id INT auto_increment primary key,
    titulo varchar(100) not null check(length(titulo) >=3),
    profesor varchar(100) not null check(length(profesor) >=3),
    dia enum('LUNES', 'MARTES', 'MIERCOLES', 'JUEVES', 'VIERNES') not null,
    turno enum('MAÑANA', 'TARDE', 'NOCHE') not null,
    activo boolean default true
     */
    private int id;
    private String titulo;
    private String profesor;
    private Dia dia;
    private Turno turno;
    private boolean activo;
    
}

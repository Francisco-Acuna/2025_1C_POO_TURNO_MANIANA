package ar.org.centro8.curso.java.entidades;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class Dato {
    private int dato;

}

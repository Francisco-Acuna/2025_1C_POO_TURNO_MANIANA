package ar.org.centro8.curso.java.interfaces.implementacion;

import ar.org.centro8.curso.java.interfaces.I_Archivo;

public class ArchivoNube implements I_Archivo{

    private String texto;

    @Override
    public void setText(String texto) {
        System.out.printf("Guardando '%s' dentro de archivo en la nube\n", texto);
        this.texto = texto;
    }

    @Override
    public String getText() {
        return texto;
    }

    @Override
    public String getTipo() {
        return "Archivo de nube";
    }

    
}

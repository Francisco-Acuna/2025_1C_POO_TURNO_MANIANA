package ar.org.centro8.curso.java.tests;

import ar.org.centro8.curso.java.entidades.Cliente;
import ar.org.centro8.curso.java.entidades.Cuenta;
import ar.org.centro8.curso.java.entidades.Dato;
import ar.org.centro8.curso.java.entidades.Direccion;
import ar.org.centro8.curso.java.entidades.Empleado;
import ar.org.centro8.curso.java.entidades.Persona;

public class TestObjetos {
    public static void main(String[] args) {
        /*
         * En Java existe la clase Class. Java, internamente, toma todas las clases
         * que nosotros creamos, como objetos de la clase Class.
         * Los atributos son tratados por Java como objetos de la clase Field, que se
         * encuentra en el paquete java.lang.reflect.Field
         * Los métodos son tratados internamente por Java como objetos de la clase Method
         * que se encuentra en el paquete Java.lang.reflect.Method
         * Esta es la base del API de reflexión de Java, la cual nos permite inspeccionar
         * y manipular información de clases, métodos y atributos en tiempo de ejecución.
         * Aunque nosotros no creamos objetos de Field o Method directamente, el
         * compilador y la JVM generan estos objetos internamente para gestionar la
         * información de nuestras clases.
         */

        Direccion direccion1 = new Direccion("Medrano", 162, "2", "Aula 8");
        Cuenta cuenta1 = new Cuenta(2345, "Dólares");
        Persona persona1 = new Empleado("Juan", "Sanchez", 51, direccion1, 121, 600000);
        Persona persona2 = new Cliente("Maria", "Ledesma", 20, direccion1, 89, cuenta1);

        System.out.println(persona1);
        System.out.println(persona2);
        persona1.getNombre();
        // persona1.getSueldoBasico(); error, getSueldoBasico() no está definido en Persona

        // Empleado empleado1 = (Empleado) persona1;
        // System.out.println(empleado1.getSueldoBasico());
        // System.out.println(empleado1);
        Empleado empleado1 = (persona1 instanceof Empleado) ? (Empleado) persona1 : null;
        System.out.println(empleado1);
    
        //los objetos tienen acceso a los miembros de su clase, más todo lo heredado
        //de la clase padre y de la clase Object (clase padre de todas la clases)
        //El objeto de una clase padre, no puede tener acceso a miembros de sus clases hijas

        System.out.println("\n********************************\n");

        Dato d1 = new Dato(2);
        Dato d2 = d1;
        Dato d3 = new Dato(d1.getDato()); //es un nuevo objeto en un nuevo espacio
        //de memoria, con el mismo estado
        Dato d4 = new Dato(2);
        String st = "2";

        //el método hashCode() es un método heredado de la clase Object
        System.out.println("d1.hashCode():" + d1.hashCode());
        System.out.println("d2.hashCode():" + d2.hashCode()); //tiene el mismo hashCode
        //que d1 porque son considerados el mismo objeto.

    }
}

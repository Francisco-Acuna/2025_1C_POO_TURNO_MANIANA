package ar.org.centro8.curso.java.ejercicio;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
public class Rectangulo {

    //atributos
    private double lado1;
    private double lado2;

    //métodos
    public double getPerimetro(){
        return (lado1 + lado2) * 2;
    }

    public double getSuperficie(){
        return lado1 * lado2;
    }

}

package ar.org.centro8.curso.java.ejercicio;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
public class TrianguloRectangulo {

    //atributos
    private double base;
    private double altura;

    //métodos
    public double getPerimetro(){
        return base + altura + Math.hypot(base, altura);
    }

    public double getSuperficie(){
        return base * altura / 2;
    }
}

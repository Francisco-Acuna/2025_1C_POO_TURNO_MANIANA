package ar.org.centro8.curso.java.entidades.herencia;

public class Cliente {
    
}

package ar.org.centro8.curso.java.entidades.relaciones;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
public class Auto {
    private String marca;
    private String modelo;
    private String color;

    /**
     * Método deprecado por el profe por considerarse inseguro u obsoleto.
     */
    @Deprecated
    public Auto(){}

    
}

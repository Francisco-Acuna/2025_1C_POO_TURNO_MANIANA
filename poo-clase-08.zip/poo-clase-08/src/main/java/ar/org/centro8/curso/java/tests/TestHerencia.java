package ar.org.centro8.curso.java.tests;

import ar.org.centro8.curso.java.entidades.herencia.Direccion;
import ar.org.centro8.curso.java.entidades.herencia.Empleado;
import ar.org.centro8.curso.java.entidades.herencia.Persona;

public class TestHerencia {
    public static void main(String[] args) {
        /*
         * Herencia
         * Es un mecanismo para reutilizar miembros de una clase.
         * Esto favorece la extensión y especialización de comportamientos.
         * Es la relación más fuerte entre clases.
         * La renocemos con las palabras "es un/a".
         * En este caso, las clases pueden derivar de otras clases.
         * La clase derivada es la subclase y la clase de la que deriva es la superclase.
         * También se las conoce como clases hijas y clase padre.
         * Una clase en Java solo puede tener una única superclase directa.
         * Java no soporta la herencia múltiple.
         */

        System.out.println("** Test de clase Direccion **");

        Direccion direccion1 = new Direccion("Jujuy", 1999, "2", "C");
        System.out.println(direccion1);

        Direccion direccion2 = new Direccion("Belgrano", 10, "PB", "H", "Moreno");
        System.out.println(direccion2);

        System.out.println("** Clase Direccion funcionando correctamente **");

        System.out.println();

        /* System.out.println("** Test Clase Persona **");

        Persona persona1 = new Persona("Burzun", "García", 30, direccion1);
        System.out.println(persona1);
        persona1.saludar();

        System.out.println("**Clase Persona funcionando correctamente**"); */

        System.out.println("**Test clase Empleado**");
        Empleado empleado1 = new Empleado("Martin", "Nogales", 20, direccion2, 100, 500000);
        System.out.println(empleado1);
        System.out.println(empleado1.getNombre());
        empleado1.saludar();


    }
}

package ar.org.centro8.curso.java.entidades.relaciones;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
public class EmpleadoComposicion {
    //Las composiciones son de las relaciones más fuertes entre clases.
    //Una clase no tiene sentido sin la instancia de la otra clase que la compone.
    //Las reconocemos con las palabras "siempre tiene un/a".
    //En este caso, un empleado siempre tiene un auto.

    private int legajo;
    private String nombre;
    private String apellido;
    @NonNull //anotación de Lombok para indicar que el atributo auto no puede ser nulo
    private Auto auto;
    //si quisiera agregar un auto nulo, daría error en tiempo de ejecución
    //de esta manera, nos aseguramos de que un empleado siempre tenga un auto.

    //un ejemplo de composición más fuerte, sería crear el objeto dentro
    //de la lógica del constructor.
    public EmpleadoComposicion(int legajo, String nombre, String apellido, String marca, String modelo, String color) {
        this.legajo = legajo;
        this.nombre = nombre;
        this.apellido = apellido;
        this.auto = new Auto(marca, modelo, color);
    }

    //no podemos crear un objeto de Empleado sin un auto
    
}

package ar.org.centro8.curso.java.entidades.varargs;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class Cliente {
    private String nombre;
    private List<Factura> facturas = new ArrayList<>();

    public Cliente(String nombre){
        this.nombre = nombre;
    }
    // public void agregarFactura(Factura factura){
    //     facturas.add(factura);
    // }

    public void agregarFactura(Factura ... factura){
        for(Factura f:factura) facturas.add(f);
    }
}

package ar.org.centro8.curso.java.tests;

import ar.org.centro8.curso.java.entidades.varargs.Cliente;
import ar.org.centro8.curso.java.entidades.varargs.Factura;

public class TestVarargs {
    public static void main(String[] args) {
        /*
         * varargs (argumentos variables)
         * Aparecen a partir del JDK 5
         * Sirven para crear métodos que permitan variar el número de parámetros que reciben
         */

        Cliente cliente1 = new Cliente("Guillermo");

        Factura f1 = new Factura(1); 
        Factura f2 = new Factura(2); 
        Factura f3 = new Factura(3); 
        Factura f4 = new Factura(4); 
        Factura f5 = new Factura(5); 

        // cliente1.agregarFactura(f1);
        // cliente1.agregarFactura(f2);
        // cliente1.agregarFactura(f3);
        // cliente1.agregarFactura(f4);
        // cliente1.agregarFactura(f5);
        
        cliente1.agregarFacturas(f1,f2,f3,f4,f5);
        System.out.println(cliente1);


    }
}

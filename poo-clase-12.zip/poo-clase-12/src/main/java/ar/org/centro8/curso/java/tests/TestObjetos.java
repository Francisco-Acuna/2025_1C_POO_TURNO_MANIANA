package ar.org.centro8.curso.java.tests;

import ar.org.centro8.curso.java.entidades.Cliente;
import ar.org.centro8.curso.java.entidades.Cuenta;
import ar.org.centro8.curso.java.entidades.Dato;
import ar.org.centro8.curso.java.entidades.Direccion;
import ar.org.centro8.curso.java.entidades.Empleado;
import ar.org.centro8.curso.java.entidades.Persona;

public class TestObjetos {
    public static void main(String[] args) {
        /*
         * En Java existe la clase Class. Java, internamente, toma todas las clases
         * que nosotros creamos, como objetos de la clase Class.
         * Los atributos son tratados por Java como objetos de la clase Field, que se
         * encuentra en el paquete java.lang.reflect.Field
         * Los métodos son tratados internamente por Java como objetos de la clase Method
         * que se encuentra en el paquete Java.lang.reflect.Method
         * Esta es la base del API de reflexión de Java, la cual nos permite inspeccionar
         * y manipular información de clases, métodos y atributos en tiempo de ejecución.
         * Aunque nosotros no creamos objetos de Field o Method directamente, el
         * compilador y la JVM generan estos objetos internamente para gestionar la
         * información de nuestras clases.
         */

        Direccion direccion1 = new Direccion("Medrano", 162, "2", "Aula 8");
        Cuenta cuenta1 = new Cuenta(2345, "Dólares");
        Persona persona1 = new Empleado("Juan", "Sanchez", 51, direccion1, 121, 600000);
        Persona persona2 = new Cliente("Maria", "Ledesma", 20, direccion1, 89, cuenta1);

        System.out.println(persona1);
        System.out.println(persona2);
        persona1.getNombre();
        // persona1.getSueldoBasico(); error, getSueldoBasico() no está definido en Persona

        // Empleado empleado1 = (Empleado) persona1;
        // System.out.println(empleado1.getSueldoBasico());
        // System.out.println(empleado1);
        Empleado empleado1 = (persona1 instanceof Empleado) ? (Empleado) persona1 : null;
        System.out.println(empleado1);
    
        //los objetos tienen acceso a los miembros de su clase, más todo lo heredado
        //de la clase padre y de la clase Object (clase padre de todas la clases)
        //El objeto de una clase padre, no puede tener acceso a miembros de sus clases hijas

        System.out.println("\n********************************\n");

        Dato d1 = new Dato(2);
        Dato d2 = d1; //referencia, no ocupa otro lugar de memoria
        Dato d3 = new Dato(d1.getDato()); //es un nuevo objeto en un nuevo espacio
        //de memoria, con el mismo estado
        Dato d4 = new Dato(2);
        String st = "2";

        //el método hashCode() es un método heredado de la clase Object
        System.out.println("d1.hashCode():" + d1.hashCode());
        System.out.println("d2.hashCode():" + d2.hashCode()); //tiene el mismo hashCode
        //que d1 porque son considerados el mismo objeto.
        System.out.println("d3.hashCode():" + d3.hashCode()); //distinto hashCode()
        System.out.println("d4.hashCode():" + d4.hashCode()); //distinto hashCode()
        System.out.println("st.hashCode():" + st.hashCode()); //distinto hashCode()
        //el código hash es un valor entero calculado por Java a partir del estado o la
        //identidad del objeto. Este valor se utiliza principalmente en estructuras de 
        //datos hash para facilitar la búsqueda y el almacenamiento eficiente de objetos.
        //No es la dirección de memoria del objeto.

        //el método equals() también está definido en Object
        //compara objetos por medio del hashCode, devuelve un booleano
        System.out.println();
        System.out.println("d1.equals(d1): " + d1.equals(d1)); //true
        System.out.println("d1.equals(d2): " + d1.equals(d2)); //true
        System.out.println("d1.equals(d3): " + d1.equals(d3)); //false
        System.out.println("d1.equals(d4): " + d1.equals(d4)); //false
        System.out.println("d1.equals(st): " + d1.equals(st)); //false

        //para que dos objetos sean considerados el mismo objeto según su estado
        //hay que sobreescribir los métodos equals() y hashCode()

        System.out.println("\n&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&\n");

        //Clase String

        //La clase String contiene un vector de caracteres, el cual es inmutable

        //tenemos varios constructores para crear un String
        String texto1 = "Cadena de Texto";
        String texto2 = new String("hola");
        String texto3 = new String("hola");

        //comparación de Strings
        //al comparar un objeto de la clase String con el operador == va a comparar que
        //sean el mismo objeto en memoria
        System.out.println(texto2 == texto3); //false
        //para comparar los Strings a nivel estado del objeto, utilizamos equals()
        System.out.println(texto2.equals(texto3)); //true

        //La clase String contiene un vector que es inmutable

        /* String cadena = "";

        for (int i = 1; i < 700000; i++) {
            cadena += "x";
        }
        System.out.println(cadena); */

        //StringBuilder y StringBuffer
        //StringBuilder es la más rápida pero no es sincronizada, es ideal para
        //entornos de un solo hilo.
        //StringBuffer es sincronizada lo que la hace un poco más lenta pero soporta
        //el multiprocesamiento.
        //Ambas mantienen internamente una secuencia de caracteres gestionada en un
        //array de caracteres que se redimensiona dinámicamente.
        //No utiliza una lista del tipo Collection ni la clase Vector para almacenar
        //estos caracteres.

        StringBuilder sb = new StringBuilder();
        StringBuffer sf = new StringBuffer();

        for (int i = 1; i < 700000; i++) {
            sf.append("x");
        }
        System.out.println(sf);


    }
}

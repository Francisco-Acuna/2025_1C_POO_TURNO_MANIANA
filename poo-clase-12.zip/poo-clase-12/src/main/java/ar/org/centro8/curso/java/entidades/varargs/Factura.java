package ar.org.centro8.curso.java.entidades.varargs;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@AllArgsConstructor
@ToString
public class Factura {
    private int numero;
}

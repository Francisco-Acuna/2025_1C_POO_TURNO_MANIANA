package ar.org.centro8.curso.java.interfaces.implementacion;

import ar.org.centro8.curso.java.interfaces.I_Archivo;

public class ArchivoBinario implements I_Archivo {

    private String texto;

    @Override
    public String getText() {
        return this.texto;
    }

    @Override
    public String getTipo() {
        return "Archivo binario";
    }

    @Override
    public void setText(String texto) {
        System.out.printf("Guardando '%s' dentro de archivo binario\n", texto);
        this.texto = texto;
    }

    

}

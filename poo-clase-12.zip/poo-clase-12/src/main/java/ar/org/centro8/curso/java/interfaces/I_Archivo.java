package ar.org.centro8.curso.java.interfaces;

import ar.org.centro8.curso.java.interfaces.implementacion.ArchivoBinario;
import ar.org.centro8.curso.java.interfaces.implementacion.ArchivoNube;
import ar.org.centro8.curso.java.interfaces.implementacion.ArchivoTexto;

public interface I_Archivo {

    /*
     * Interfaces en Java
     * 
     * - No tienen constructores, ya que no se crean objetos de una interfaz.
     * - Todas las variables declaradas (atributos) en una interfaz son implícitamente
     * public static final.
     * - Puede tener métodos abstractos.
     * - Por defecto, los métodos de una interfaz son públicos. Pero, a partir de Java 9
     * se pueden definir métodos privados para uso interno.
     * - Los métodos en una interfaz, son por defecto, abstractos y no tienen cuerpo. Las
     * clases que implementen la interfaz deben ponerle el cuerpo al método. Pero a partir
     * de Java 8, se pueden definir métodos default y estáticos que sí incluyen implementación.
     * Este código será compartido por todas las clases que implementen la interfaz. Que
     * pueden sobreescribir estos métodos si requieren una implementación específica.
     * - Una clase puede implementar todas las interfaces que desee.
     * - Como una clase puede implementar varias interfaces, se produce la situación de algo
     * similar a una herencia múltiple (que no existe en Java).
     * - No llega a ser una herencia múltiple porque no hereda constructores ni atributos de clase.
     * - Lo que hereda son las firmas de los métodos y las implementaciones de los métodos
     * default si los hubiera. Lo que le permite a la clase combinar comportamientos de
     * distintas fuentes.
     */

    //no hace falta escribir las palabras public y abstract porque por defecto son así
    //se pueden obviar, o se pueden poner para una mayor claridad o visibilidad en el código.

    /**
     * Método para escribir un archivo.
     * @param texto : texto a escribir en el archivo.
     */ 
    void setText(String texto);

    /**
     * Método para leer un archivo.
     * @return retorna el texto del archivo.
     */
    String getText();

    /**
     * Método que retorna el tipo de archivo en forma de cadena.
     * @return
     */
    String getTipo();

    default void info(){
        System.out.println("I_Archivo: Interfaz para la gestión de archivos. " + 
                            "Define el comportamiento común para todas las implementaciones.");
    }

    //Factory Methods (métodos de fábrica)
    //Permiten cetralizar la creación de instancias de las clases que implementan la
    //interfaz. Esto sirve para ocultar la lógica de instanciación y decidir, en función
    //de los parámetros, qué implementación devolver.
    public static I_Archivo crearArchivo(String tipo){
        switch (tipo.toLowerCase()) {
            case "texto": return new ArchivoTexto();
            case "binario": return new ArchivoBinario();
            case "nube": return new ArchivoNube();
            default: throw new IllegalArgumentException("Tipo de Archivo no soportado: " + tipo);
        }
    }
    //esto es un polimorfimsmo por Interfaz
    //aunque el método retorne un objeto del tipo I_Archivo, la instancia concreta
    //puede ser de cualquiera de las clases que implementen la interfaz. Por lo tanto,
    //el objeto retornado puede comportarse de distintas maneras según la implementación
    //concreta que se devuelva. 
    
    //ejemplo de métodso privados dentro de una interfaz
    //los métodos privados, permiten reutilizar código interno.

    //método default que valida y muestra el texto
    default void mostrarTextoFormateado(){
        String texto = getText();
        if(esTextoValido(texto)){
            //si es válido, formatea el texto y lo muestra
            System.out.println("Texto formateado: " + formatearTexto(texto));
        } else{
            System.out.println("El texto no es válido para formatear");
        }
    }

    //método privado para formatear el texto
    private String formatearTexto(String texto){
        return texto.trim().toUpperCase();
    }

    //método privado estático para validar que el texto no sea nulo ni vacío
    private static boolean esTextoValido(String texto){
        return texto != null && !texto.trim().isBlank();
    }


}

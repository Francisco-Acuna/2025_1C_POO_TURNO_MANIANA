package ar.org.centro8.curso.java.tests;

import java.util.Scanner;

import ar.org.centro8.curso.java.interfaces.I_Archivo;

public class TestInterfaces {
    public static void main(String[] args) {
        //creamos una referencia a la interfaz

        I_Archivo archivo;

        //inicialización
        Scanner teclado = new Scanner(System.in);
        System.out.println("Ingrese una oración");
        String mensaje = teclado.nextLine();
        System.out.println("Seleccione en qué tipo de archivo quiere guardar su texto:");
        System.out.println("TEXTO - BINARIO - NUBE");
        String opcion = teclado.nextLine();
        teclado.close();
        //teclado.close() cierra el objeto de Scanner, es decir que libera los recursos.
        //en programas pequeños o contextos educativos simples, no tiene relevancia.
        //No es crítico. En aplicaciones reales es una buena práctica liberar recursos.

        archivo = I_Archivo.crearArchivo(opcion);

        archivo.setText(mensaje);
        archivo.info();
        System.out.println(archivo.getTipo());
        System.out.println(archivo.getText());
        archivo.mostrarTextoFormateado();

    }
}

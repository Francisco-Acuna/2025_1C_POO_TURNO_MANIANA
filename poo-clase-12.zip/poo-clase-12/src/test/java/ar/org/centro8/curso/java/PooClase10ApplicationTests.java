package ar.org.centro8.curso.java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PooClase10ApplicationTests {

	@Test
	void contextLoads() {
	}

}

package ar.org.centro8.curso.java.repositories;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.centro8.curso.java.entities.Alumno;
import ar.org.centro8.curso.java.repositories.interfaces.I_AlumnoRepository;

/*
 * En el mundo del desarrollo de software, cuando hablamos de clases que se encarguen de
 * interacturar con la base de datos para guardar, buscar, o actualizar los objetos, se vana referir 
 * como DAO (Data Acces Object) y Repository(Repositorio).
 * Ambos cumplen con el mismo propósito: abstraer la lógica de la persistencia para que el 
 * resto de nuestra aplicación no tenga que preocuparse por los detalles de SQL o de cómo
 * funciona la base de datos.
 * DAO es el término más tradicional para una clase que implementa directamente estas operaciones
 * de acceso a datos de bajo nivel SQL
 * Repository es un concepto más moderno y de más alto nivel, muy poplar en frameworks como 
 * Spring Boot con Spring Data JPA
 * Un repositorio sería como una "colección de objetos en memoria", aunque por detrás estén
 * guardados en la base de datos.
 */
@Repository
public class AlumnoDAO implements I_AlumnoRepository{
    //creamos un objeto de DataSource que nos permite obtener la conexión a la BD
    private final DataSource DATASOURCE;
    
    //definimos una serie de atributos estáticos (para ahorrar memoria) y constantes (para 
    //garantizar que no se cambie la consulta en tiempo de ejecución)
    //Representan consultas SQL.
    //Agrupadas al inicio nos permiten una mayor claridad de código y facilita el mantenimiento
    private static final String SQL_CREATE =
        "INSERT INTO alumnos(nombre, apellido, edad, idCurso, activo) VALUES (?,?,?,?,?)";
    //los signos de pregunta son marcadores de posición para los valores que se establecerán
    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM alumnos WHERE id=?";
    private static final String SQL_FIND_ALL =
        "SELECT * FROM alumnos";
    private static final String SQL_UPDATE =
        "UPDATE alumnos SET nombre=?, apellido=?, edad=?, idCurso=?, activo=? WHERE id=?";
    private static final String SQL_DELETE =
        "DELETE FROM alumnos WHERE id=?";
    private static final String FIND_BY_CURSO =
        "SELECT * FROM alumnos WHERE idCurso=?";

    public AlumnoDAO(DataSource dataSource){
        this.DATASOURCE = dataSource;
    }
    // de esta manera, el repositorio queda configurado con la fuente de conexiones
    //que usará siempre, el repositorio no crea su propio datasource, sino que se le proporciona
    //uno configurado con HikariCP
    //Mantiene un diseño limpio y testeable, ya que se pueden crear varias instancias con distintos
    //DataSource, esto puedo representar distintas bases como la de producción, desarrollo, test, etc
    //sin necesidad de tocar código interno.

    @Override
    public void create(Alumno alumno) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) { //obtenemos la conexión
            //PreparedStatement es na interfaz de Java que representa una plantilla de consulta
            //o comando SQL. Sirve para ejecutar consultas SQL de forma segura y eficiente, especialmente
            //cuando estas consultas usan valores variables. 
            //Llamamos al método preparedStatement de la conexión, primero le pasamos la constante de la
            //sentencia SQL que queremos ejecutar y luego, Statement.RETURN_GENERATED_KEYS le indica a la 
            //base de datos que después de ejecutar el INSERT debe devolver las claves generadas automáticamente
            //(por lo general es el ID autoincrementable de la nueva fila)
            ps.setString(1, alumno.getNombre()); //el 1 se refiere a la primera posición del ?        
        } catch (Exception e) {
            // TODO: handle exception
        }
    }

    @Override
    public Alumno findById(int id) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findById'");
    }

    @Override
    public List<Alumno> findAll() throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findAll'");
    }

    @Override
    public int update(Alumno alumno) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'update'");
    }

    @Override
    public int delete(int id) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'delete'");
    }

    @Override
    public List<Alumno> findByCurso(int idCurso) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findByCurso'");
    }






}

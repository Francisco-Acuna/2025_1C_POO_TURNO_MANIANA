package ar.org.centro8.curso.java.Tests;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

/*
 * Esta clase utilizará el contexto de Spring Boot para obtener los DAOs y ejecutar operaciones.
 * Esta clase, no es parte de la lógica de negocio de la aplicación en sí, si no una herramienta
 * para probar manualmente que nuestras capas de entidades y accesos a datos (DATO/Repository)
 * funcionan correctamente. Es como un banco de pruebas.
 * Hacemos esto, porque antes de construir una Interfaz Gráfica, necesitamos estar seguros de que
 * nuestros métodos interactúan bien con la base de datos.
 */
@SpringBootApplication(scanBasePackages = "ar.org.centro8.curso.java")
/*
 * Con esta anotación le estamos indicando a Spring Boot que inicie la aplicación escaneando todos
 * los componentes en el paquete principal ar.org.centro8.curso.java y sus subpaquetes. Spring se
 * va a encargar de crear y configurar todas las piezas de la aplicación (DataSource, DAO, etc.).
 * Para esto, tenemos que poner la anotación de @Repository en los DAOs par que Spring los detecte
 * y los registre como "beans" (objetos gestionados por Spring). 
 * Spring termina realizando inyección de dependencias
 */
public class TestRepositories {
    public static void main(String[] args) {
        ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class,args);
        /*
         * Lo que buscamos es iniciar el contexto de Spring Boot
         * Eso levante toda la configuración, incluyendo el DataSource y los DAOs
         * El método run() devuelve el contexto de toda la aplicación
         * SpringApplication.run()
         * Es la línea que arranca la aplicación de Spring Boot completa. 
         * Esto significa que:
         * lee el application.properties
         * configura el DataSource (con HikariCP)
         * Si tenemos spring.sql.init.mode=always, ejecuta schema_DDL.sql y data_DML.sql, limpiando
         * y repoblando nuestra base de datos.
         * Crea instancias de nuestros DAOs y repositories
         */
}

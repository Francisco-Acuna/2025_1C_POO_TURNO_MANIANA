package ar.org.centro8.curso.java.Tests;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import ar.org.centro8.curso.java.entities.Alumno;
import ar.org.centro8.curso.java.repositories.AlumnoDAO;
import ar.org.centro8.curso.java.repositories.CursoDAO;
import ar.org.centro8.curso.java.repositories.interfaces.I_AlumnoRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_CursoRepository;

/*
 * Esta clase utilizará el contexto de Spring Boot para obtener los DAOs y ejecutar operaciones.
 * Esta clase, no es parte de la lógica de negocio de la aplicación en sí, si no una herramienta
 * para probar manualmente que nuestras capas de entidades y accesos a datos (DATO/Repository)
 * funcionan correctamente. Es como un banco de pruebas.
 * Hacemos esto, porque antes de construir una Interfaz Gráfica, necesitamos estar seguros de que
 * nuestros métodos interactúan bien con la base de datos.
 */
@SpringBootApplication(scanBasePackages = "ar.org.centro8.curso.java")
/*
 * Con esta anotación le estamos indicando a Spring Boot que inicie la aplicación escaneando todos
 * los componentes en el paquete principal ar.org.centro8.curso.java y sus subpaquetes. Spring se
 * va a encargar de crear y configurar todas las piezas de la aplicación (DataSource, DAO, etc.).
 * Para esto, tenemos que poner la anotación de @Repository en los DAOs par que Spring los detecte
 * y los registre como "beans" (objetos gestionados por Spring). 
 * Spring termina realizando inyección de dependencias
 */
public class TestRepositories {
    public static void main(String[] args) {
        //ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class,args);
        /*
         * Lo que buscamos es iniciar el contexto de Spring Boot
         * Eso levante toda la configuración, incluyendo el DataSource y los DAOs
         * El método run() devuelve el contexto de toda la aplicación
         * SpringApplication.run()
         * Es la línea que arranca la aplicación de Spring Boot completa. 
         * Esto significa que:
         * lee el application.properties
         * configura el DataSource (con HikariCP)
         * Si tenemos spring.sql.init.mode=always, ejecuta schema_DDL.sql y data_DML.sql, limpiando
         * y repoblando nuestra base de datos.
         * Crea instancias de nuestros DAOs y repositories y les inyecta el DataSource. Esto se
         * conoce como Inversión de Control o Inversión de Dependencias
         */

        //El objeto de ConfigurableApplicationContext es el contenedor de Inversión de Control (IoC)
        //de Spring Boot. Es el corazón de la aplicación Spring Boot y es el responsable de:
        //- Escanear el código en busca de anotaciones
        //- Instancias todos los beans que detecte
        //- Manejar la Inyección de Dependencias (DI), es decir, los beans entre sí. Por ejemplo
        //inyectar el DataSource en AlumnoDao
        //- Cargar la configuración (application.properties)
        //ConfigurableApplicationContext es closeable, con lo cual debemos cerrarlo para liberar
        //los recursos. Para eso utilizamos un try with resources

        try (ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class,args);) {
            I_AlumnoRepository alumnoDAO = context.getBean(AlumnoDAO.class);
            I_CursoRepository cursoDAO = context.getBean(CursoDAO.class);

            //Pruebas para Alumnos

            //TEST 1: Crear un nuevo alumno
            System.out.println(">>> Test 1: creando un nuevo alumno...");
            Alumno nuevoAlumno = new Alumno(0, "Ricardo", "Iorio", 62, 1, true); //el idCurso 1 es Matemática
            alumnoDAO.create(nuevoAlumno); //el id se asigna dentro del método create
            if(nuevoAlumno.getId()>0){
                System.out.println(" ## Alumno creado con el ID:" + nuevoAlumno.getId());
                System.out.println(nuevoAlumno);
            } else{
                System.err.println(" ¡¡ ERROR - No se pudo crear el alumno !!");
            }


            //TEST 2: Buscar un Alumno por ID (existente)
            System.out.println(">>> Test 2: Buscando alumno por ID " + nuevoAlumno.getId() + "...");
            Alumno alumnoEncontrado = alumnoDAO.findById(nuevoAlumno.getId());
            if(alumnoEncontrado!=null){
                System.out.println(" ## Alumno econtrado: " + alumnoEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - No se econtró el alumno con el ID " + nuevoAlumno.getId());
            }

        } catch (Exception e) {
            // TODO: handle exception
        }

    }

}

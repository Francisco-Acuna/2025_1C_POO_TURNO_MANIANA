package ar.org.centro8.curso.java.Tests;

import java.io.InputStream;
import java.sql.Connection;
import java.util.Properties;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class TestConnection {
    public static void main(String[] args) {
        Properties props = new Properties();
        //carga el application.properties desde el src/main/resources. 
        //Creamos un objeto Properties para cargar el fichero de configuración

        //InputStream representa un flujo de bytes
        try (InputStream in = TestConnection.class //obtengo el objeto Class de esta clase
                                            .getClassLoader() //obtengo el ClassLoader, es el responsable
                                            //de cargar las clases y recursos en tiempo de ejecución
                                            .getResourceAsStream("application.properties")) {
                                                //busca el archivo con el nombre que le pasemos como parámetro
                                                //lo devuelve como un flujo de bytes para leer su contenido
            if(in == null){
                System.err.println("No encontré application.properties en el classpath");
                return;
            }
            props.load(in);
            //cargar todas las propiedades (clave-valor)
        } catch (Exception e) {
            System.err.println("Error cargando properties: " + e.getMessage());
            return;
        }

        //creamos la configuración del pool
        HikariConfig config = new HikariConfig();
        //leemos la URL de la BD de las properties y la asignamos
        config.setJdbcUrl(props.getProperty("spring.datasource.url"));
        //usuario y contraseña para la conexión
        config.setUsername(props.getProperty("spring.datasource.username"));
        config.setPassword(props.getProperty("spring.datasource.password"));

        //creamos el DataSource con el pool de conexiones y probamos la conexión
        try (HikariDataSource ds = new HikariDataSource(config);
                Connection conn = ds.getConnection()) { //obtenemos una conexión
            if(conn.isValid(2)){ //comprueba si la conexión es válida
                //el parámetro indica la cantidad de segundos que tiene el driver JDBC para
                //esperar a confirmar la conexión con el servidor.
                //Ese timeout evita que el programa se quede colgado indefinidamente si la 
                //base de datos no responde.
                System.out.println("Conexión exitosa a: " + conn.getMetaData().getURL());
                //con getMetada() obtenemos información sobre la conexión activa
                //con getURL() obtenemos la URL de la conexión utilizada
            } else{
                System.err.println("Conexión establecida pero no válida");
            }
        } catch (Exception e) {
            System.err.println("No se pudo conectar: " + e.getMessage());
        }




    }
}

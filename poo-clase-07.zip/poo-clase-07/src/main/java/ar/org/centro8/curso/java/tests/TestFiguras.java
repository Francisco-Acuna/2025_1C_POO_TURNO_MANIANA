package ar.org.centro8.curso.java.tests;

import ar.org.centro8.curso.java.ejercicio.Circulo;
import ar.org.centro8.curso.java.ejercicio.Rectangulo;
import ar.org.centro8.curso.java.ejercicio.TrianguloRectangulo;

public class TestFiguras {
    public static void main(String[] args) {
        
        //creamos un objeto de la clase Rectangulo
        Rectangulo rectangulo1 = new Rectangulo(5, 4);
        System.out.println(rectangulo1);
        System.out.println("El perímetro del rectángulo es: " + rectangulo1.getPerimetro());
        System.out.println("La superficie del rectángulo es: " + rectangulo1.getSuperficie());
    
        //creamos un objeto de la clase TrianguloRectangulo
        TrianguloRectangulo trianguloRectangulo1 = new TrianguloRectangulo(17, 25);
        System.out.println("El perímetro del triángulo es: " + trianguloRectangulo1.getPerimetro());
        System.out.println("La superficie del triángulo es: " + trianguloRectangulo1.getSuperficie());
    
        //creamos un objeto de la clase Circulo
        Circulo circulo1 = new Circulo(12.2);
        System.out.println(circulo1);
        System.out.println("El perímetro del círculo es: " + circulo1.getPerimetro());
        System.out.println("La superficie del círculo es: " + circulo1.getSuperficie());
    }
}

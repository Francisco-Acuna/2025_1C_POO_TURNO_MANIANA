package ar.org.centro8.curso.java.entidades.relaciones;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class EmpleadoAgregaciones {
    //Las agregaciones son un tipo de relación un poco más fuerte entre clases
    //son de las más utilizadas, la reconocemos con las palabras tiene un/a
    //Por ejemplo, en este caso, un empleado tiene un auto
    
    private int legajo;
    private String nombre;
    private String apellido;
    private Auto auto;

    //creamos el constructor sin el auto, ya que el auto es opcional en un principio
    public EmpleadoAgregaciones(int legajo, String nombre, String apellido) {
        this.legajo = legajo;
        this.nombre = nombre;
        this.apellido = apellido;
    }

    //el objeto se crea sin un auto, y luego con el setter le puedo agregar un auto

}

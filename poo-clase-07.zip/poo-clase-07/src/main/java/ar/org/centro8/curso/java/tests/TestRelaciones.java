package ar.org.centro8.curso.java.tests;

import java.util.List;

import ar.org.centro8.curso.java.entidades.relaciones.Auto;
import ar.org.centro8.curso.java.entidades.relaciones.ClienteMayorista;
import ar.org.centro8.curso.java.entidades.relaciones.ClienteMinorista;
import ar.org.centro8.curso.java.entidades.relaciones.Cuenta;
import ar.org.centro8.curso.java.entidades.relaciones.EmpleadoAgregaciones;
import ar.org.centro8.curso.java.entidades.relaciones.EmpleadoAsociacionSimple;

public class TestRelaciones {
    public static void main(String[] args) {
        System.out.println("** Test de la clase Cuenta **");

        Cuenta cuenta1 = new Cuenta(1, "args");
        System.out.println(cuenta1);

        cuenta1.depositar(50000);
        System.out.println(cuenta1.getSaldo());

        cuenta1.debitar(10000);
        System.out.println(cuenta1.getSaldo());

        Cuenta cuenta2 = new Cuenta(2, "dólares");
        cuenta2.depositar(20000);
        cuenta2.debitar(30000);
        System.out.println(cuenta2.getSaldo());

        System.out.println("** Clase Cuenta funcionando correctamente **");

        System.out.println();

        System.out.println("** Test de la clase ClienteMinorista **");

        ClienteMinorista cliente1 = new ClienteMinorista(1, "Jose", "Larralde", cuenta1);
        System.out.println(cliente1);
        // cliente1.depositar(1000000); 
        //error, el método depositar no existe en la clase ClienteMinorista
        cliente1.getCuenta().depositar(1000000);
        System.out.println(cliente1.getCuenta().getSaldo());

        //creamos un apuntador, un apuntador es una referencia
        //no ocupa más lugar en memoria
        Cuenta cta = cliente1.getCuenta();
        cta.depositar(25000);
        System.out.println(cta);
        System.out.println(cliente1);

        System.out.println("** Clase ClienteMinorista funcionando correctamente **");

        System.out.println();

        System.out.println("** Test de la clase ClienteMayorista **");

        ClienteMayorista cliente2 = new ClienteMayorista(2, "Tureco", "Medrano 162");
        System.out.println(cliente2);

        //creamos un apuntador a la lista de cuentas para facilitar el manejo
        List<Cuenta> cuentas = cliente2.getCuentas();

        //con el método add() agregamos cuentas a la lista
        cuentas.add(cuenta2); //índice 0
        cuentas.add(new Cuenta(3, "reales")); //índice 1
        cuentas.add(new Cuenta(4, "libras esterlinas")); //índice 2

        //con el método get() obtengo una cuenta del listado de cuentas
        //se pasa como parámetro un número entero que representa al índice
        cuentas.get(1).depositar(10000);
        System.out.println(cliente2);
        System.out.println(cuentas.get(0));

        System.out.println("** Clase ClienteMayorista funcionando correctamente **");

        System.out.println("\n===================================\n");

        System.out.println("** Test clase Auto **");

        Auto auto1 = new Auto("Peugeot", "308", "azul");
        System.out.println(auto1);

        Auto auto2 = new Auto("Peugeot", "504", "negro tachero");
        System.out.println(auto2);

        System.out.println("** Clase Auto funcionando correctamente **");

        System.out.println();

        System.out.println("** Test de la clase EmpleadoAsociacionSimple **");

        EmpleadoAsociacionSimple empleado1 = new EmpleadoAsociacionSimple(1, "Arnold", "Schwarzenegger");
        System.out.println(empleado1);
        empleado1.usarAuto(auto1);

        System.out.println("** Clase EmpleadoAsociacionSimple funcionando correctamente **");

        System.out.println();

        System.out.println("** Test clase EmpleadoAgregaciones **");

        EmpleadoAgregaciones empleado2 = new EmpleadoAgregaciones(2, "Susana", "Gimenez");
        System.out.println(empleado2);
        empleado2.setAuto(auto2);
        System.out.println(empleado2);

    }
}

package ar.org.centro8.curso.java.Tests;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class TestMaps {
    public static void main(String[] args) {
        /*
        Interface Map
        La interfaz Map permite representar un diccionario o una estructura de datos 
        de pares clave-valor. En un Map, cada clave (key) se asocia a un valor (value), 
        y las claves no tienen por qué ser números ni consecutivas; pueden ser de cualquier 
        tipo de objeto (por ejemplo, String, Integer, etc.). Esto permite representar 
        relaciones o asociaciones en las que el "índice" es una clave arbitraria.

        Aspectos importantes:
        - Un Map no extiende de Collection; aunque forma parte del framework de Collections, 
        es una interfaz independiente.
        - Cada clave es única dentro del mapa; si se agrega un valor con una clave ya existente, 
        se reemplaza el valor anterior.
        - A partir de JDK 8, Map incorpora un método forEach que recibe un BiConsumer (una 
        expresión lambda que acepta la clave y el valor) para recorrer de forma automática 
        todos sus pares.
        - Aunque Map no implementa la interfaz Stream, es posible obtener streams a partir de 
        sus vistas: keySet(), values() o entrySet().
        */

        System.out.println("** Interface Map **");

        Map<String, String> mapaSemana;
        //Map<k, v> -> Map<key, value>
        //no se pueden declarar llaves ni valor de tip de datos priomitivos

        //implementacines de Map

        //HashMap: implementa un mapa sin ningún orden garantizado, es una de las implementaciones
        //más eficientes para operaciones de inserción y búsqueda
        // mapaSemana = new HashMap<>();
        
        //LinkedHashMap: Mantiene el orden de inserción, lo que permite recorrer el mapa en 
        //el mismo orden en el que se insertaron los elementos
        mapaSemana = new LinkedHashMap<>();

        //TreeMap: Ordena las claves según su orden natural, para ello, requiere que las clases
        //implementen la interfaz Comparable.
        mapaSemana = new TreeMap<>();

        //con el método .put() agrego un elemento
        mapaSemana.put("lu", "lunes");
        mapaSemana.put("ma", "martes");
        mapaSemana.put("mi", "miércoles");
        mapaSemana.put("ju", "jueves");
        mapaSemana.put("vi", "viernes");
        mapaSemana.put("sa", "sábado");
        mapaSemana.put("do", "domingo");
        //se pueden repetir los valores, pero no las llaves

        //con el método .get() obtengo un elemento
        System.out.println(mapaSemana.get("coso"));

        System.out.println();

        //recorrido del map
        System.out.println("Recorrido de mapaSemana:");
        mapaSemana.forEach((k,v) -> System.out.println(k + " -> " + v));


    }
}
